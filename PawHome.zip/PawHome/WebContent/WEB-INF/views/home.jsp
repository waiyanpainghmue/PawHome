<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PawHome | Rescue · Adopt · Give Love</title>
  <meta name="description" content="Meet animals cared for by PawHome, discover adoption stories and support daily animal care.">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap-icons.min.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head>
<body class="pawhome-home">
<%@ include file="header.jspf" %>
<c:if test="${not empty donationTicker}">
  <section class="donor-ticker" aria-label="Thank you to PawHome supporters"><div class="donor-ticker-label">WITH THANKS TO OUR SUPPORTERS</div><div class="donor-ticker-window"><div class="donor-ticker-track"><c:forEach var="item" items="${donationTicker}"><span><b><c:out value="${item.donor_name}"/></b> <c:out value="${item.ticker_text}"/> <i>♥</i></span></c:forEach><c:forEach var="item" items="${donationTicker}"><span aria-hidden="true"><b><c:out value="${item.donor_name}"/></b> <c:out value="${item.ticker_text}"/> <i>♥</i></span></c:forEach></div></div></section>
</c:if>
<main>
  <section class="home-hero-v2">
    <div class="container-fluid px-4 px-xl-5">
      <div class="row align-items-center g-4 g-xl-5">
        <div class="col-lg-6 home-hero-copy-v2">
          <p class="home-kicker"> PAWHOME ANIMAL RESCUE</p>
          <h1>EVERY PAW<br>DESERVES A<br><em>SAFE HOME.</em></h1>
          <p class="home-hero-lead">A second chance starts with care. Meet the animals in our care, learn their stories and find out how you can help them reach a safe, loving home.</p>
          <div class="home-hero-actions">
            <a class="btn btn-paw btn-lg" href="${pageContext.request.contextPath}/pets">Meet the animals </a>
            <a class="btn btn-outline-paw btn-lg" href="${pageContext.request.contextPath}/about">Our story</a>
          </div>
          <!-- <div class="home-hero-caption"><span class="caption-rule"> Rescue with care. Adopt with love.</span></div> -->
        </div>
        <div class="col-lg-6">
          <div class="home-hero-art-v2">
            <div class="home-art-yellow"></div>
            <div class="home-art-pink"></div>
            <div class="home-art-photo">
              <img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=1400&q=85" alt="A friendly dog looking for a loving home">
            </div>
            <div class="home-art-caption"><strong>MEET YOUR NEW BEST FRIEND</strong><span>Find a pet to love</span></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="home-paths-section">
    <div class="container-fluid px-4 px-xl-5">
      <div class="home-section-intro">
        <p class="home-kicker"> SMALL ACTIONS. BIG SECOND CHANCES.</p>
        <h2>HOW YOU CAN HELP</h2>
      </div>
      <div class="row g-3 g-xl-4">
        <div class="col-sm-6 col-xl-4">
          <a class="home-path-card path-card-pink" href="${pageContext.request.contextPath}/pets">
            <span class="path-number">01</span><h3>ADOPT</h3><p>Meet the animals in our care and apply to welcome one into your family.</p><span class="path-link">Find a companion </span>
          </a>
        </div>
        <div class="col-sm-6 col-xl-4">
          <a class="home-path-card path-card-yellow" href="${pageContext.request.contextPath}/donate">
            <span class="path-number">02</span><h3>DONATE</h3><p>Help cover food, medical care, daily meals and essential supplies.</p><span class="path-link">Support their care </span>
          </a>
        </div>
        <div class="col-sm-6 col-xl-4">
          <a class="home-path-card path-card-cream" href="${pageContext.request.contextPath}/rescue/report">
            <span class="path-number">03</span><h3>REPORT</h3><p>Tell us when you see an injured, unwell or abandoned animal that needs help.</p><span class="path-link">Report an animal </span>
          </a>
        </div>
      </div>
    </div>
  </section>

  <section class="home-pets-section section-space">
    <div class="container-fluid px-4 px-xl-5">
      <div class="home-section-heading-row">
        <div><p class="home-kicker"><span></span> READY FOR A NEW CHAPTER</p><h2>MEET THE<br><em>ANIMALS.</em></h2><p class="section-intro-copy">Every animal has a story. Get to know the ones currently in PawHome's care and see who may be the right companion for you.</p></div>
        <a class="btn btn-outline-paw" href="${pageContext.request.contextPath}/pets">View all animals </a>
      </div>
      <div class="row g-4 mt-2">
        <c:forEach var="pet" items="${pets}" varStatus="loop">
          <c:if test="${loop.index lt 4}">
            <div class="col-sm-6 col-xl-3">
              <article class="pet-card home-pet-card-v2">
                <a class="pet-image" href="${pageContext.request.contextPath}/pet?id=${pet.petId}">
                  <c:choose>
                    <c:when test="${not empty pet.imagePath}"><img src="${pageContext.request.contextPath}/${pet.imagePath}" alt="<c:out value='${pet.petName}'/>" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80'"></c:when>
                    <c:otherwise><img src="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80" alt="Animal available for adoption"></c:otherwise>
                  </c:choose>
                  <span class="pet-status">AVAILABLE</span>
                </a>
                <div class="pet-card-body">
                  <div class="pet-card-title-row"><div><h3><c:out value="${pet.petName}"/></h3><p><c:out value="${pet.breed}"/></p></div><span class="pet-kind"><c:out value="${pet.species}"/></span></div>
                  <div class="pet-meta"><span><c:out value="${pet.gender}"/></span><span><c:out value="${pet.age}"/> years</span></div>
                  <a class="pet-card-link" href="${pageContext.request.contextPath}/pet?id=${pet.petId}">Get to know </a>
                </div>
              </article>
            </div>
          </c:if>
        </c:forEach>
        <c:if test="${empty pets}"><div class="col-12"><div class="empty-state"><h3>No animals are listed just yet.</h3><p>Please check back soon or contact PawHome for more information.</p></div></div></c:if>
      </div>
    </div>
  </section>

  <section class="home-feeding-stories">
    <div class="container-fluid px-4 px-xl-5">
      <div class="feeding-heading"><div><p class="home-kicker"><span></span> CARE IN ACTION</p><h2>MEALS MADE<br><em>WITH LOVE.</em></h2><p>Real moments from PawHome. These photos are shared after our team has received support and cared for the animals.</p></div><a class="btn btn-outline-paw" href="${pageContext.request.contextPath}/donate">Support their care <i class="bi bi-arrow-up-right ms-2"></i></a></div>
      <div class="row g-3 g-lg-4 feeding-story-grid">
        <c:forEach var="story" items="${todayMealStories}" varStatus="loop"><c:if test="${loop.index lt 3}"><div class="col-md-4"><article class="feeding-story-card"><div class="feeding-story-image"><img src="${pageContext.request.contextPath}/${story.photo_path}" alt="PawHome animals receiving their ${story.meal_slot} meal" loading="lazy"></div><div class="feeding-story-caption"><span><c:out value="${story.meal_slot}"/> · <c:out value="${story.meal_date}"/></span><h3><c:out value="${story.caption}"/></h3><small>With thanks to <c:out value="${story.public_name}"/></small></div></article></div></c:if></c:forEach>
        <c:if test="${empty todayMealStories}"><div class="col-12"><div class="feeding-empty"><div><p class="home-kicker"><span></span> TODAY AT PAWHOME</p><h3>Every meal is a small act of care.</h3><p>When our team uploads today's feeding photos, they will appear here.</p></div><a class="btn btn-paw" href="${pageContext.request.contextPath}/donate">Be part of today's care</a></div></div></c:if>
      </div>
    </div>
  </section>

  <section class="home-donation-cta">
    <div class="container-fluid px-4 px-xl-5"><div class="donation-cta-inner"><div><p class="home-kicker home-kicker-light"><span></span> FOOD · MEDICAL CARE · ESSENTIALS</p><h2>HELP THEM FEEL<br><em>SAFE & CARED FOR.</em></h2><p>Choose breakfast, lunch or dinner, support medical treatment, or donate essential supplies. PawHome will contact you to arrange your donation directly.</p></div><a class="btn btn-paw btn-lg" href="${pageContext.request.contextPath}/donate">Choose how to help <i class="bi bi-arrow-up-right ms-2"></i></a></div></div>
  </section>

  <section class="home-rescue-section">
    <div class="container-fluid px-4 px-xl-5">
      <div class="home-rescue-panel">
        <div><p class="home-kicker"><span></span> SEE AN ANIMAL THAT NEEDS HELP?</p><h2>DON'T WALK<br><em>PAST.</em></h2><p>Share what you saw, where you saw it and how the animal is doing. A clear report helps our team understand the situation and decide what to do next.</p></div>
        <a class="btn btn-paw btn-lg" href="${pageContext.request.contextPath}/rescue/report">Submit a rescue report <i class="bi bi-arrow-up-right ms-2"></i></a>
      </div>
    </div>
  </section>
</main>
<%@ include file="footer.jspf" %>
</body>
</html>
