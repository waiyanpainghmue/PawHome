<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Create an account | PawHome</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head>
<body class="auth-body auth-body-register">
<header class="auth-topbar">
  <a class="auth-brand" href="${pageContext.request.contextPath}/home"><img src="${pageContext.request.contextPath}/images/pawhome-logo.svg" alt=""><span>PAWHOME<small>RESCUE · ADOPT · GIVE LOVE</small></span></a>
  <a class="auth-back-link" href="${pageContext.request.contextPath}/home">Back to PawHome</a>
</header>
<main class="auth-main-v2 auth-main-register">
  <div class="auth-frame auth-frame-register">
    <section class="auth-form-side">
      <div class="auth-form-content">
        <p class="auth-kicker"> JOIN THE PAWHOME COMMUNITY</p>
        <h1>LET'S MAKE<br>ROOM FOR <em>LOVE.</em></h1>
        <p class="auth-intro">Create an account to apply for adoption and keep track of your PawHome activity.</p>
        <c:if test="${not empty error}"><div class="alert alert-danger auth-alert"><c:out value="${error}"/></div></c:if>
        <form method="post" action="${pageContext.request.contextPath}/register" class="auth-form-v2">
          <div class="auth-fields-grid">
            <div class="auth-field"><label for="registerName">FULL NAME</label><input class="form-control" id="registerName" name="fullName" maxlength="100" required autocomplete="name" placeholder="Your full name" value="<c:out value='${param.fullName}'/>" autofocus></div>
            <div class="auth-field"><label for="registerEmail">EMAIL ADDRESS</label><input class="form-control" id="registerEmail" type="email" name="email" maxlength="150" required autocomplete="email" placeholder="you@example.com" value="<c:out value='${param.email}'/>"></div>
            <div class="auth-field"><label for="registerPhone">PHONE NUMBER <span class="optional-label">OPTIONAL</span></label><input class="form-control" id="registerPhone" type="tel" name="phone" maxlength="30" autocomplete="tel" placeholder="09xxxxxxxxx" value="<c:out value='${param.phone}'/>"></div>
            <div class="auth-field"><label for="registerAddress">CITY / TOWNSHIP <span class="optional-label">OPTIONAL</span></label><input class="form-control" id="registerAddress" name="address" maxlength="2000" autocomplete="address-level2" placeholder="Your area" value="<c:out value='${param.address}'/>"></div>
          </div>
          <div class="auth-field"><label for="registerPassword">PASSWORD</label><div class="auth-password-wrap"><input class="form-control" id="registerPassword" type="password" name="password" minlength="8" required autocomplete="new-password" placeholder="Create a password"><button class="auth-show-password" type="button" data-password-toggle="registerPassword" aria-label="Show password">SHOW</button></div><small class="auth-field-help">Use at least 8 characters.</small></div>
          <button class="btn btn-paw auth-submit" type="submit">CREATE ACCOUNT</button>
        </form>
        <p class="auth-switch-v2">Already have an account? <a href="${pageContext.request.contextPath}/login">Sign in</a></p>
      </div>
    </section>
    <aside class="auth-visual-side auth-visual-register">
      <div class="auth-visual-copy"><p class="auth-visual-kicker">GOOD THINGS BEGIN WITH YOU</p><h2>OPEN YOUR<br>HEART.<br><em>CHANGE A LIFE.</em></h2><p>Join a community that believes every animal deserves safety, patience and a loving home.</p></div>
      <div class="auth-visual-image auth-register-image"><img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1100&q=85" alt="A curious cat looking toward the camera"></div>
      <div class="auth-visual-foot"><span>PAWHOME ANIMAL RESCUE</span><span>02 / JOIN US</span></div>
    </aside>
  </div>
  <p class="auth-bottom-note">A safe home. A new beginning. <a href="${pageContext.request.contextPath}/about">Learn about PawHome</a></p>
</main>
<script>
(() => {
  document.querySelectorAll('[data-password-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.getAttribute('data-password-toggle'));
      if (!input) return;
      const reveal = input.type === 'password';
      input.type = reveal ? 'text' : 'password';
      button.textContent = reveal ? 'HIDE' : 'SHOW';
      button.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
    });
  });
})();
</script>
</body>
</html>
