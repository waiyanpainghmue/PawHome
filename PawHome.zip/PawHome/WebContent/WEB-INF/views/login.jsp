<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Log in | PawHome</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head>
<body class="auth-body auth-body-login">
<header class="auth-topbar">
  <a class="auth-brand" href="${pageContext.request.contextPath}/home"><img src="${pageContext.request.contextPath}/images/pawhome-logo.svg" alt=""><span>PAWHOME<small>RESCUE · ADOPT · GIVE LOVE</small></span></a>
  <a class="auth-back-link" href="${pageContext.request.contextPath}/home">Back to PawHome</a>
</header>
<main class="auth-main-v2">
  <div class="auth-frame auth-frame-login">
    <section class="auth-form-side">
      <div class="auth-form-content">
        <p class="auth-kicker"> WELCOME BACK</p>
        <h1>GOOD TO<br>SEE YOU <em>AGAIN!</em></h1>
        <p class="auth-intro">Sign in to keep up with your applications and stay connected with the animals in our care.</p>
        <c:if test="${not empty error}"><div class="alert alert-danger auth-alert"><c:out value="${error}"/></div></c:if>
        <c:if test="${param.registered=='1'}"><div class="alert alert-success auth-alert">Your account is ready. Please sign in to continue.</div></c:if>
        <c:if test="${param.disabled=='1'}"><div class="alert alert-warning auth-alert">This account is currently unavailable. Please contact PawHome.</div></c:if>
        <form method="post" action="${pageContext.request.contextPath}/login" class="auth-form-v2">
          <input type="hidden" name="next" value="<c:out value='${param.next}'/>">
          <div class="auth-field"><label for="loginEmail">EMAIL ADDRESS</label><input class="form-control" id="loginEmail" type="email" name="email" required autocomplete="email" placeholder="you@example.com" value="<c:out value='${param.email}'/>" autofocus></div>
          <div class="auth-field"><div class="auth-label-row"><label for="loginPassword">PASSWORD</label></div><div class="auth-password-wrap"><input class="form-control" id="loginPassword" type="password" name="password" required autocomplete="current-password" placeholder="Enter your password"><button class="auth-show-password" type="button" data-password-toggle="loginPassword" aria-label="Show password">SHOW</button></div></div>
          <button class="btn btn-paw auth-submit" type="submit">SIGN IN</button>
        </form>
        <p class="auth-switch-v2">New to PawHome? <a href="${pageContext.request.contextPath}/register">Create an account</a></p>
      </div>
    </section>
    <aside class="auth-visual-side auth-visual-login">
      <div class="auth-visual-copy"><p class="auth-visual-kicker">A SECOND CHANCE STARTS HERE</p><h2>CARE<br>CHANGES<br><em>EVERYTHING.</em></h2><p>Every small act of kindness helps an animal move closer to a safe home.</p></div>
      <div class="auth-visual-image auth-login-image"><img src="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=1100&q=85" alt="A friendly golden retriever"></div>
      <div class="auth-visual-foot"><span>PAWHOME ANIMAL RESCUE</span><span>01 / WELCOME</span></div>
    </aside>
  </div>
  <p class="auth-bottom-note">A safe home. A new beginning. <a href="${pageContext.request.contextPath}/about">Learn about PawHome</a></p>
</main>
<script>
(() => {
  document.querySelectorAll('[data-password-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.getAttribute('data-password-toggle'));
      if (!input) return;
      const reveal = input.type === 'password';
      input.type = reveal ? 'text' : 'password';
      button.textContent = reveal ? 'HIDE' : 'SHOW';
      button.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
    });
  });
})();
</script>
</body>
</html>
