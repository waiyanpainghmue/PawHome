<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Adopter dashboard | PawHome</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head>
<body>
    <%@ include file="header.jspf" %>
    
    <main class="page-shell">
        <div class="container-fluid px-4 px-xl-5">
            
            <div class="page-heading">
                <div class="eyebrow"><span></span> ADOPTER SPACE</div>
                <h1>Hello, <em>${sessionScope.authUser.fullName}.</em></h1>
                <p>Keep track of your adoption journey and discover animals waiting for a home.</p>
            </div>
            
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="stat-card">
                        <small>My adoption applications</small>
                        <strong>${applicationCount}</strong>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="stat-card">
                        <small>Unread notifications</small>
                        <strong>${unreadNotifications}</strong>
                    </div>
                </div>
            </div>
            
            <div class="content-panel">
                <h2>Your PawHome</h2>
                <div class="row g-3">
                    <div class="col-md-6">
                        <a class="dashboard-action" href="${pageContext.request.contextPath}/pets">
                            <i class="bi bi-search-heart-fill"></i>
                            <span>
                                <b>Find a pet</b>
                                <small>Browse animals looking for a home</small>
                            </span>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a class="dashboard-action" href="${pageContext.request.contextPath}/my-applications">
                            <i class="bi bi-hearts"></i>
                            <span>
                                <b>My applications</b>
                                <small>Review your application statuses</small>
                            </span>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a class="dashboard-action" href="${pageContext.request.contextPath}/rescue/report">
                            <i class="bi bi-geo-alt"></i>
                            <span>
                                <b>Report an animal</b>
                                <small>Tell the team about an animal needing help</small>
                            </span>
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a class="dashboard-action" href="${pageContext.request.contextPath}/donate">
                            <i class="bi bi-gift"></i>
                            <span>
                                <b>Make a donation request</b>
                                <small>Choose meals, medical care or supplies</small>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            
        </div>
    </main>
    
    <%@ include file="footer.jspf" %>
</body>
</html>