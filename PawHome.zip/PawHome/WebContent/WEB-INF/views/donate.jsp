<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Donate | PawHome</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap-icons.min.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head><body class="pawhome-donate-page">
<%@ include file="header.jspf" %>
<main class="page-shell donate-shell">
  <div class="container-fluid px-4 px-xl-5 donate-container">
    <c:if test="${not empty param.submitted}">
      <section class="donation-success mb-4"><p class="donate-kicker">REQUEST RECEIVED</p><h2>Thank you for thinking of our animals.</h2><p>Your request number is <strong><c:out value="${param.submitted}"/></strong>. PawHome will contact you using the details you provided to confirm the arrangements. No payment is made on this website.</p></section>
    </c:if>
    <c:if test="${param.error=='1'}"><div class="alert alert-danger"><c:out value="${sessionScope.donationError}"/><c:remove var="donationError" scope="session"/></div></c:if>

    <section class="donate-intro">
      <div><p class="donate-kicker">A LITTLE CARE GOES A LONG WAY</p><h1>Give in a way<br><em>that matters.</em></h1><p>Choose a meal, help with medical care, or provide essential supplies. Tell us what you have in mind and our team will contact you to arrange it.</p></div>
      <aside class="donate-promise"><span>PAWHOME PROMISE</span><strong>No online payment.</strong><p>We will never ask you to enter bank details on this website. An Admin will contact you and record a donation only after it is actually received.</p></aside>
    </section>

    <section class="donation-request-layout">
      <div class="donation-form-card">
        <div class="donation-form-heading"><span>01</span><div><h2>Make a donation request</h2><p>Choose one way to support. Every request is reviewed by PawHome.</p></div></div>
        <form method="post" action="${pageContext.request.contextPath}/donate" id="donationRequestForm">
          <input type="hidden" name="requestToken" value="${requestToken}">
          <fieldset class="donate-fieldset"><legend>What would you like to support?</legend>
            <div class="donation-type-grid">
              <label class="donation-type-option"><input type="radio" name="requestType" value="MEAL" checked><span><b>Daily meals</b><small>Breakfast, lunch or dinner</small></span></label>
              <label class="donation-type-option"><input type="radio" name="requestType" value="MEDICAL_CARE"><span><b>Medical care</b><small>Treatment, medicine and check-ups</small></span></label>
              <label class="donation-type-option"><input type="radio" name="requestType" value="SUPPLIES"><span><b>Care supplies</b><small>Food, bedding and essentials</small></span></label>
              <label class="donation-type-option"><input type="radio" name="requestType" value="GENERAL_SUPPORT"><span><b>General support</b><small>Help where it is needed most</small></span></label>
            </div>
          </fieldset>

          <fieldset class="donate-fieldset" id="mealSelectionBlock"><legend>Choose the meal(s)</legend><p class="donate-helper">Select any combination. You can choose just one meal or all three.</p>
            <div class="meal-choice-grid">
              <label class="meal-choice"><input type="checkbox" name="mealSlots" value="BREAKFAST"><span><b>Breakfast</b><small>မနက်စာ</small></span></label>
              <label class="meal-choice"><input type="checkbox" name="mealSlots" value="LUNCH"><span><b>Lunch</b><small>နေ့လယ်စာ</small></span></label>
              <label class="meal-choice"><input type="checkbox" name="mealSlots" value="DINNER"><span><b>Dinner</b><small>ညစာ</small></span></label>
            </div>
          </fieldset>

          <div class="row g-3">
            <div class="col-md-6"><label class="form-label" for="requestedDate">Preferred date *</label><input class="form-control" type="date" id="requestedDate" name="requestedDate" value="${todayDate}" min="${todayDate}" required></div>
            <div class="col-md-6"><label class="form-label" for="estimatedAmount">Estimated amount (MMK, optional)</label><input class="form-control" type="number" id="estimatedAmount" name="estimatedAmount" min="1" step="1" placeholder="You can leave this blank"></div>
            <div class="col-12" id="purposeField"><label class="form-label" for="purpose">What would you like to support? *</label><input class="form-control" id="purpose" name="purpose" maxlength="180" required placeholder="e.g. medicine for rescued puppies, wound treatment"></div>
            <div class="col-12"><label class="form-label" for="message">Additional details *</label><textarea class="form-control" id="message" name="message" rows="3" maxlength="3000" required placeholder="Tell us what you would like to donate or any arrangements we should know about."></textarea></div>
          </div>

          <fieldset class="donate-fieldset donor-details"><legend>Your contact details</legend>
            <div class="row g-3">
              <div class="col-md-6"><label class="form-label" for="donorName">Your name *</label><input class="form-control" id="donorName" name="donorName" maxlength="100" required value="<c:out value='${sessionScope.authUser.fullName}'/>" placeholder="Full name"></div>
              <div class="col-md-6"><label class="form-label" for="donorPhone">Phone number *</label><input class="form-control" id="donorPhone" name="donorPhone" maxlength="30" required value="<c:out value='${sessionScope.authUser.phone}'/>" placeholder="09xxxxxxxxx"></div>
              <div class="col-12"><label class="form-label" for="donorEmail">Email (optional)</label><input class="form-control" type="email" id="donorEmail" name="donorEmail" maxlength="150" value="<c:out value='${sessionScope.authUser.email}'/>" placeholder="you@example.com"></div>
            </div>
          </fieldset>
          <button class="btn btn-paw btn-lg donate-submit" type="submit">Submit donation request <i class="bi bi-arrow-up-right ms-2"></i></button>
          <p class="donate-privacy">Your contact details are visible only to PawHome Admin. Submitting this form is a request, not a payment or confirmation that a donation has been received.</p>
        </form>
      </div>
      <aside class="donate-side-card">
        <p class="donate-kicker">WHAT HAPPENS NEXT</p><h2>Simple, personal<br><em>and transparent.</em></h2>
        <ol class="donate-steps"><li><b>Send your request</b><span>Tell us the support you have in mind.</span></li><li><b>Our team contacts you</b><span>We confirm the date, details and practical arrangements.</span></li><li><b>Donation is received</b><span>Admin records it only after checking what arrived.</span></li><li><b>Your kindness is shared</b><span>With permission, your name may appear in our thank-you highlights.</span></li></ol>
        <div class="donate-contact-box"><b>Prefer to speak with us?</b><c:if test="${not empty siteSettings.contact_phone}"><a href="tel:${siteSettings.contact_phone}"><c:out value="${siteSettings.contact_phone}"/></a></c:if><c:if test="${not empty siteSettings.contact_email}"><a href="mailto:${siteSettings.contact_email}"><c:out value="${siteSettings.contact_email}"/></a></c:if><c:if test="${not empty siteSettings.messenger_url}"><a href="${siteSettings.messenger_url}" target="_blank" rel="noopener">Message PawHome</a></c:if></div>
      </aside>
    </section>
  </div>
</main>
<%@ include file="footer.jspf" %>
<script>
(function(){
 const form=document.getElementById('donationRequestForm'); if(!form)return;
 const meals=document.getElementById('mealSelectionBlock'); const purpose=document.getElementById('purposeField');
 function refresh(){const type=form.querySelector('input[name="requestType"]:checked').value;const isMeal=type==='MEAL';meals.hidden=!isMeal;purpose.hidden=isMeal;document.getElementById('purpose').required=!isMeal;form.querySelectorAll('input[name="mealSlots"]').forEach(x=>{x.disabled=!isMeal;if(!isMeal)x.checked=false;});}
 form.querySelectorAll('input[name="requestType"]').forEach(x=>x.addEventListener('change',refresh));
 form.addEventListener('submit',function(e){const type=form.querySelector('input[name="requestType"]:checked').value;if(type==='MEAL'&&!form.querySelector('input[name="mealSlots"]:checked')){e.preventDefault();alert('Please select at least one meal.');}}); refresh();
})();
</script>
</body></html>
