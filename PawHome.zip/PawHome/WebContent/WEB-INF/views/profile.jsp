<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Profile | PawHome</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
</head>
<body>
<%@ include file="header.jspf" %>
<main class="page-shell">
  <div class="container" style="max-width: 960px;">
    <div class="page-heading text-center">
      <div class="eyebrow justify-content-center"><span></span> YOUR PAWHOME ACCOUNT</div>
      <h1>My <em>profile.</em></h1>
      <p>Keep your contact details up to date so PawHome can reach you about your applications.</p>
    </div>

    <c:if test="${param.updated=='1'}"><div class="alert alert-success rounded-4">Your profile has been updated successfully.</div></c:if>
    <c:if test="${not empty error}"><div class="alert alert-danger rounded-4"><c:out value="${error}"/></div></c:if>

    <div class="profile-edit-card p-3 p-md-4">
      <form method="post" enctype="multipart/form-data" class="row g-4 align-items-start">
        <div class="col-lg-4">
          <section class="profile-summary text-center h-100">
            <div class="profile-photo-large mx-auto mb-3" id="profilePreviewWrap">
              <c:choose>
                <c:when test="${not empty sessionScope.authUser.profileImage}">
                  <img id="profilePreview" src="${pageContext.request.contextPath}/${sessionScope.authUser.profileImage}" alt="Your profile photo">
                </c:when>
                <c:otherwise>
                  <span class="profile-photo-placeholder" id="profileInitial"><c:out value="${fn:toUpperCase(fn:substring(sessionScope.authUser.fullName,0,1))}"/></span>
                  <img id="profilePreview" src="" alt="Profile photo preview" hidden>
                </c:otherwise>
              </c:choose>
            </div>
            <h2 class="h5 mb-1"><c:out value="${sessionScope.authUser.fullName}"/></h2>
            <p class="small mb-3"><c:out value="${sessionScope.authUser.email}"/></p>
            <label for="profileImage" class="btn btn-outline-paw">Choose profile photo</label>
            <input class="form-control mt-2" type="file" id="profileImage" name="profileImage" accept="image/jpeg,image/png,image/webp" hidden>
            <p class="profile-upload-help mt-3 mb-0">JPG, PNG or WebP. Maximum 5 MB.</p>
          </section>
        </div>

        <div class="col-lg-8">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label" for="fullName">Full name <span class="text-danger">*</span></label>
              <input class="form-control" id="fullName" name="fullName" maxlength="100" required value="<c:out value='${sessionScope.authUser.fullName}'/>">
            </div>
            <div class="col-md-6">
              <label class="form-label" for="email">Email address</label>
              <input class="form-control" id="email" value="<c:out value='${sessionScope.authUser.email}'/>" readonly>
              <div class="form-text">Email is used for login and cannot be changed here.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label" for="phone">Phone number</label>
              <input class="form-control" type="tel" id="phone" name="phone" maxlength="30" value="<c:out value='${sessionScope.authUser.phone}'/>" placeholder="09xxxxxxxxx">
            </div>
            <div class="col-12">
              <label class="form-label" for="address">Address</label>
              <textarea class="form-control" id="address" name="address" rows="3" maxlength="2000" placeholder="Township, city"><c:out value="${sessionScope.authUser.address}"/></textarea>
            </div>
            <div class="col-12">
              <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between pt-2">
                <span class="small">Account type: <strong><c:out value="${sessionScope.authUser.roleName}"/></strong></span>
                <button class="btn btn-paw px-4" type="submit">Save profile</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</main>
<%@ include file="footer.jspf" %>
<script>
(() => {
  const picker = document.getElementById('profileImage');
  const preview = document.getElementById('profilePreview');
  const initial = document.getElementById('profileInitial');
  if (!picker || !preview) return;
  picker.addEventListener('change', () => {
    const file = picker.files && picker.files[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
      picker.value = '';
      alert('Choose a JPG, PNG or WebP image up to 5 MB.');
      return;
    }
    preview.src = URL.createObjectURL(file);
    preview.hidden = false;
    if (initial) initial.hidden = true;
  });
})();
</script>
</body>
</html>
