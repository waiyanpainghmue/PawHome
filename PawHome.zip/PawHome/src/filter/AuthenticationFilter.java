package filter;

import entity.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import util.DBConnection;

public class AuthenticationFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException {
        HttpServletRequest req=(HttpServletRequest)request;
        HttpServletResponse res=(HttpServletResponse)response;
        String path=req.getRequestURI().substring(req.getContextPath().length());
        HttpSession session=req.getSession(false);
        User user=(User)(session==null?null:session.getAttribute("authUser"));
        if(user==null){
            String next=path+(req.getQueryString()==null?"":"?"+req.getQueryString());
            res.sendRedirect(req.getContextPath()+"/login?next="+URLEncoder.encode(next,StandardCharsets.UTF_8));
            return;
        }
        if((path.equals("/admin")||path.startsWith("/admin/")) && !"ADMIN".equals(user.getRoleName())){res.sendError(HttpServletResponse.SC_FORBIDDEN);return;}
        if((path.equals("/adopt")||path.equals("/my-applications")) && !"USER".equals(user.getRoleName())){res.sendError(HttpServletResponse.SC_FORBIDDEN);return;}
        // Re-check account state for every protected request. A disabled account cannot
        // continue using an already authenticated browser session.
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT account_status FROM users WHERE user_id=?")){
            p.setInt(1,user.getUserId());
            try(ResultSet r=p.executeQuery()){
                if(!r.next()||!"ACTIVE".equals(r.getString(1))){session.invalidate();res.sendRedirect(req.getContextPath()+"/login?disabled=1");return;}
            }
        }catch(Exception e){throw new ServletException("Unable to verify account status",e);}
        chain.doFilter(request,response);
    }
}
