package util;
public class PasswordHashTool {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) { System.out.println("Usage: java util.PasswordHashTool <new-password>"); return; }
        System.out.println(PasswordUtil.hash(args[0]));
    }
}
