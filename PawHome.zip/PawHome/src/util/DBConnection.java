package util;
import java.io.InputStream; import java.sql.Connection; import java.sql.DriverManager; import java.util.Properties;
public final class DBConnection {
 private static final Properties CONFIG=new Properties();
 static {try(InputStream in=DBConnection.class.getClassLoader().getResourceAsStream("db.properties")){if(in!=null)CONFIG.load(in);Class.forName("com.mysql.cj.jdbc.Driver");}catch(Exception e){throw new ExceptionInInitializerError(e);}}
 private DBConnection(){}
 public static Connection getConnection()throws Exception{
  String url=System.getProperty("pawhome.db.url",System.getenv().getOrDefault("PAWHOME_DB_URL",CONFIG.getProperty("db.url","jdbc:mysql://localhost:3306/pawhome_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Yangon&characterEncoding=UTF-8")));
  String user=System.getProperty("pawhome.db.user",System.getenv().getOrDefault("PAWHOME_DB_USER",CONFIG.getProperty("db.user","root")));
  String pass=System.getProperty("pawhome.db.password",System.getenv().getOrDefault("PAWHOME_DB_PASSWORD",CONFIG.getProperty("db.password","12345")));
  return DriverManager.getConnection(url,user,pass);
 }
}
