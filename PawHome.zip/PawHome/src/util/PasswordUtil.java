package util;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordUtil {
    private static final int ITERATIONS = 210_000;
    private static final int KEY_BITS = 256;
    private PasswordUtil() {}
    public static String hash(String password) throws Exception {
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        byte[] key = derive(password.toCharArray(), salt, ITERATIONS);
        return "pbkdf2$" + ITERATIONS + "$" + Base64.getEncoder().withoutPadding().encodeToString(salt) + "$" + Base64.getEncoder().withoutPadding().encodeToString(key);
    }
    public static boolean verify(String password, String encoded) throws Exception {
        if (encoded == null || !encoded.startsWith("pbkdf2$")) return false;
        String[] p = encoded.split("\\$"); if (p.length != 4) return false;
        int rounds = Integer.parseInt(p[1]); byte[] salt = Base64.getDecoder().decode(p[2]); byte[] expected = Base64.getDecoder().decode(p[3]);
        return java.security.MessageDigest.isEqual(expected, derive(password.toCharArray(), salt, rounds));
    }
    private static byte[] derive(char[] password, byte[] salt, int rounds) throws Exception {
        KeySpec spec = new PBEKeySpec(password, salt, rounds, KEY_BITS);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    }
}
