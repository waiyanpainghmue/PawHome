package entity;

public class User {
    private int userId;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private String preferredLanguage;
    private String roleName;
    private String verificationStatus;
    private String profileImage;

    public User(int id, String name, String email, String phone, String address, String language, String role) {
        this(id, name, email, phone, address, language, role, null, null);
    }

    public User(int id, String name, String email, String phone, String address, String language,
                String role, String verificationStatus) {
        this(id, name, email, phone, address, language, role, verificationStatus, null);
    }

    public User(int id, String name, String email, String phone, String address, String language,
                String role, String verificationStatus, String profileImage) {
        this.userId = id;
        this.fullName = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.preferredLanguage = language;
        this.roleName = role;
        this.verificationStatus = verificationStatus;
        this.profileImage = profileImage;
    }

    public int getUserId() { return userId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public String getPreferredLanguage() { return preferredLanguage; }
    public String getRoleName() { return roleName; }
    public String getVerificationStatus() { return verificationStatus; }
    public String getProfileImage() { return profileImage; }
}
