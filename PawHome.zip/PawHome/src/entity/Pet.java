package entity;
public class Pet {
    private int petId, age;
    private String petName,species,breed,gender,color,description,listingStatus,imagePath,location,healthStatus,vaccinationStatus,intakeType;
    public Pet(int id,String name,String species,String breed,String gender,int age,String color,String description,String status,String image,String location){
        this(id,name,species,breed,gender,age,color,description,status,image,location,null,null,null);
    }
    public Pet(int id,String name,String species,String breed,String gender,int age,String color,String description,String status,String image,String location,String healthStatus,String vaccinationStatus,String intakeType){
        this.petId=id;this.petName=name;this.species=species;this.breed=breed;this.gender=gender;this.age=age;this.color=color;this.description=description;this.listingStatus=status;this.imagePath=image;this.location=location;this.healthStatus=healthStatus;this.vaccinationStatus=vaccinationStatus;this.intakeType=intakeType;
    }
    public int getPetId(){return petId;} public String getPetName(){return petName;} public String getSpecies(){return species;} public String getBreed(){return breed;} public String getGender(){return gender;} public int getAge(){return age;} public String getColor(){return color;} public String getDescription(){return description;} public String getListingStatus(){return listingStatus;} public String getImagePath(){return imagePath;} public String getLocation(){return location;} public String getHealthStatus(){return healthStatus;} public String getVaccinationStatus(){return vaccinationStatus;} public String getIntakeType(){return intakeType;}
}
