package controller;

import dao.ApplicationDAO;
import dao.PetDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;

public class AdoptionServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        try {
            if ("/adopt".equals(req.getServletPath())) {
                int petId=Integer.parseInt(req.getParameter("petId"));
                var pet=new PetDAO().get(petId);
                if(pet==null){res.sendError(404);return;}
                if(!"AVAILABLE".equals(pet.getListingStatus())){res.sendError(409,"This pet is no longer available for applications.");return;}
                req.setAttribute("pet",pet);
                req.getRequestDispatcher("/WEB-INF/views/adoption-form.jsp").forward(req,res);
                return;
            }
            User user=(User)req.getSession().getAttribute("authUser");
            req.setAttribute("applications",new ApplicationDAO().forUser(user.getUserId()));
            req.getRequestDispatcher("/WEB-INF/views/applications.jsp").forward(req,res);
        } catch(NumberFormatException e){res.sendError(400);} catch(Exception e){throw new ServletException(e);}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");
        User user=(User)req.getSession().getAttribute("authUser");
        try {
            if("withdraw".equals(req.getParameter("action"))){new ApplicationDAO().withdraw(user.getUserId(),Integer.parseInt(req.getParameter("id")));res.sendRedirect(req.getContextPath()+"/my-applications?withdrawn=1");return;}
            new ApplicationDAO().apply(Integer.parseInt(req.getParameter("petId")),user.getUserId(),req.getParameter("phone"),req.getParameter("address"),req.getParameter("reason"),req.getParameter("home"),req.getParameter("care"),new BigDecimal(req.getParameter("budget")));
            res.sendRedirect(req.getContextPath()+"/my-applications?submitted=1");
        } catch(Exception e) {
            try {
                int petId=Integer.parseInt(req.getParameter("petId"));
                req.setAttribute("pet",new PetDAO().get(petId));
                req.setAttribute("error",e.getMessage());
                req.getRequestDispatcher("/WEB-INF/views/adoption-form.jsp").forward(req,res);
            } catch(Exception nested){throw new ServletException(nested);}
        }
    }
}
