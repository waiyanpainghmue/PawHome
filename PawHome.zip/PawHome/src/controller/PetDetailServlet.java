package controller;
import dao.PetDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
public class PetDetailServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        try {
            int id=Integer.parseInt(req.getParameter("id"));PetDAO dao=new PetDAO();var pet=dao.get(id);
            if(pet==null||"PENDING".equals(pet.getListingStatus())||"REJECTED".equals(pet.getListingStatus())||"DRAFT".equals(pet.getListingStatus())){res.sendError(404);return;}
            req.setAttribute("pet",pet);req.setAttribute("images",dao.images(id));
            req.getRequestDispatcher("/WEB-INF/views/pet-detail.jsp").forward(req,res);
        }catch(NumberFormatException e){res.sendError(400);}catch(Exception e){throw new ServletException(e);}
    }
}
