package controller;

import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import service.UploadStorage;
import util.DBConnection;
import java.io.IOException;
import java.sql.*;
import java.util.List;

public class RescueReportServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException {
        try { q.setAttribute("siteSettings",new dao.CommunityDAO().settings()); }
        catch(Exception e){throw new ServletException(e);}
        q.getRequestDispatcher("/WEB-INF/views/rescue-report.jsp").forward(q,s);
    }
    @Override protected void doPost(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException {
        q.setCharacterEncoding("UTF-8"); List<String> saved=List.of();
        try {
            String name=required(q.getParameter("reporterName"),100,"Name");
            String phone=required(q.getParameter("reporterPhone"),30,"Phone number");
            String location=required(q.getParameter("location"),255,"Location");
            String condition=required(q.getParameter("condition"),100,"Animal condition");
            String description=required(q.getParameter("description"),4000,"Description");
            saved=UploadStorage.saveImages(q.getParts(),"reports",1);
            User user=(User)(q.getSession(false)==null?null:q.getSession(false).getAttribute("authUser"));
            String image=saved.isEmpty()?null:saved.get(0);
            try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO rescue_reports(reporter_user_id,reporter_name,reporter_phone,location,animal_condition,description,image_path,report_status) VALUES(?,?,?,?,?,?,?,'PENDING')")){
                if(user==null)p.setNull(1,Types.INTEGER);else p.setInt(1,user.getUserId());
                p.setString(2,name);p.setString(3,phone);p.setString(4,location);p.setString(5,condition);p.setString(6,description);p.setString(7,image);p.executeUpdate();
            }
            s.sendRedirect(q.getContextPath()+"/rescue/report?submitted=1");
        } catch(Exception e) {
            UploadStorage.deleteStored(saved);
            try { q.setAttribute("siteSettings",new dao.CommunityDAO().settings()); } catch(Exception ignored) { }
            q.setAttribute("error",e.getMessage()==null?"Report could not be submitted.":e.getMessage());
            q.getRequestDispatcher("/WEB-INF/views/rescue-report.jsp").forward(q,s);
        }
    }
    private String required(String value,int max,String label){if(value==null||value.isBlank()||value.trim().length()>max)throw new IllegalArgumentException("Enter a valid "+label+" (maximum "+max+" characters).");return value.trim();}
}
