package controller;
import dao.PetDAO;
import dao.CommunityDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.sql.Date;
public class HomeServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        try{
            PetDAO pets=new PetDAO();CommunityDAO community=new CommunityDAO();
            req.setAttribute("pets",pets.find("","ALL",""));
            req.setAttribute("donationTicker",community.donationTicker());
            req.setAttribute("todayMealStories",community.todayMealStories(Date.valueOf(LocalDate.now(ZoneId.of("Asia/Yangon")))));
            req.setAttribute("siteSettings",community.settings());
            req.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(req,res);
        }catch(Exception e){throw new ServletException(e);}
    }
}
