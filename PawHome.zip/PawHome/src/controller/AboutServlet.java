package controller;
import jakarta.servlet.http.*; import jakarta.servlet.*; import java.io.IOException;
public class AboutServlet extends HttpServlet { protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{req.getRequestDispatcher("/WEB-INF/views/about.jsp").forward(req,res);} }
