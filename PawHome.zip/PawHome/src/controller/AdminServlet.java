package controller;

import dao.AdminDAO;
import dao.ApplicationDAO;
import dao.CommunityDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;
import service.UploadStorage;
import java.util.List;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

@MultipartConfig(maxFileSize=5242880, maxRequestSize=35000000, fileSizeThreshold=1048576)
public class AdminServlet extends HttpServlet {
    private final AdminDAO adminDAO=new AdminDAO();
    private final CommunityDAO communityDAO=new CommunityDAO();
    private String ip(HttpServletRequest req){return req.getRemoteAddr();}
    private String tab(HttpServletRequest req){String t=req.getPathInfo();t=t==null?"dashboard":t.replaceFirst("^/","");return t.isBlank()?"dashboard":t;}
    private boolean validTab(String t){return t!=null && Set.of("dashboard","users","pets","applications","donations","rescue","messages","settings").contains(t);}

    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        String current=tab(req);
        try {
            switch(current){
                case "dashboard" -> req.setAttribute("metrics",adminDAO.metrics());
                case "users" -> req.setAttribute("users",adminDAO.users(req.getParameter("q"),req.getParameter("role")));
                case "pets" -> req.setAttribute("pets",adminDAO.pets(req.getParameter("q"),req.getParameter("species"),req.getParameter("status")));
                case "applications" -> req.setAttribute("applications",new ApplicationDAO().all());
                case "donations" -> {req.setAttribute("donationRequests",communityDAO.adminDonationRequests());req.setAttribute("receivedReceipts",communityDAO.receivedDonationReceipts());req.setAttribute("todayDate",LocalDate.now(ZoneId.of("Asia/Yangon")).toString());}
                case "rescue" -> {req.setAttribute("reports",adminDAO.rescueReports());req.setAttribute("cases",adminDAO.rescueCases());}
                case "messages" -> req.setAttribute("messages",communityDAO.messages());
                case "settings" -> req.setAttribute("siteSettings",communityDAO.settings());
                default -> {res.sendError(404);return;}
            }
            req.setAttribute("tab",current);
            req.getRequestDispatcher("/WEB-INF/views/admin-console.jsp").forward(req,res);
        } catch(Exception e){throw new ServletException(e);}
    }

    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");
        User admin=(User)req.getSession().getAttribute("authUser");
        String action=req.getParameter("action");
        String current=req.getParameter("tab");
        if(!validTab(current))current="dashboard";
        try {
            switch(action==null?"":action){
                case "user-status" -> adminDAO.setUserStatus(admin.getUserId(),integer(req,"id"),req.getParameter("status"),ip(req));
                case "pet-status" -> adminDAO.setPetStatus(admin.getUserId(),integer(req,"id"),req.getParameter("status"),ip(req));
                case "application-review" -> new ApplicationDAO().review(admin.getUserId(),integer(req,"id"),req.getParameter("status"),ip(req));
                case "application-sign" -> new ApplicationDAO().signContract(admin.getUserId(),integer(req,"id"),ip(req));
                case "application-complete" -> new ApplicationDAO().complete(admin.getUserId(),integer(req,"id"),ip(req));
                case "application-cancel" -> new ApplicationDAO().cancelApproved(admin.getUserId(),integer(req,"id"),ip(req));
                case "donation-request-status" -> communityDAO.updateDonationRequest(admin.getUserId(),integer(req,"requestId"),req.getParameter("status"),req.getParameter("adminNote"),ip(req));
                case "donation-request-receive" -> {
                    String amount=req.getParameter("amountReceived");String meal=req.getParameter("mealId");
                    communityDAO.recordRequestReceipt(admin.getUserId(),integer(req,"requestId"),(meal==null||meal.isBlank())?null:Integer.valueOf(meal),req.getParameter("donationKind"),amount==null||amount.isBlank()?null:new BigDecimal(amount),req.getParameter("itemDescription"),date(req.getParameter("receivedDate")),req.getParameter("publicName"),"on".equals(req.getParameter("showPublic")),req.getParameter("receiptToken"),ip(req));
                }
                case "donation-story-create" -> {
                    java.util.Collection<Part> parts=req.getParts();java.util.List<Part> photos=new java.util.ArrayList<>();for(Part part:parts)if("storyImages".equals(part.getName()))photos.add(part);
                    List<String> saved=UploadStorage.saveImages(photos,"donation-stories",6);
                    try { communityDAO.addDonationStories(admin.getUserId(),integer(req,"receiptId"),date(req.getParameter("mealDate")),req.getParameter("caption"),saved,"on".equals(req.getParameter("publish")),ip(req)); }
                    catch(Exception ex){UploadStorage.deleteStored(saved);throw ex;}
                }
                case "rescue-review" -> adminDAO.reviewRescueReport(admin.getUserId(),integer(req,"id"),req.getParameter("status"),ip(req));
                case "rescue-case-status" -> adminDAO.setRescueCaseStatus(admin.getUserId(),integer(req,"caseId"),req.getParameter("status"),ip(req));
                case "contact-status" -> communityDAO.updateMessage(admin.getUserId(),integer(req,"id"),req.getParameter("status"),ip(req));
                case "site-settings" -> {
                    Map<String,String> values=new LinkedHashMap<>();
                    for(String key:Set.of("organization_name","contact_phone","contact_email","facebook_url","messenger_url","instagram_url","organization_address","office_hours"))values.put(key,req.getParameter(key));
                    communityDAO.saveSettings(admin.getUserId(),values,ip(req));
                }
                default -> throw new IllegalArgumentException("Unknown administration action.");
            }
            res.sendRedirect(req.getContextPath()+"/admin/"+current+"?updated=1");
        } catch(Exception e){
            req.getSession().setAttribute("adminError",e.getMessage()==null?"The requested operation could not be completed.":e.getMessage());
            res.sendRedirect(req.getContextPath()+"/admin/"+current+"?error=1");
        }
    }
    private int integer(HttpServletRequest req,String name){return Integer.parseInt(req.getParameter(name));}
    private Date date(String value){return value==null||value.isBlank()?null:Date.valueOf(value);}
}
