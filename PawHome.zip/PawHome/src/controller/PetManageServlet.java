package controller;

import dao.PetDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import service.UploadStorage;
import java.io.IOException;
import java.util.List;

public class PetManageServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        String path=req.getServletPath();
        if(path.endsWith("/edit")){
            try{int id=Integer.parseInt(req.getParameter("id"));PetDAO dao=new PetDAO();var pet=dao.getForAdmin(id);if(pet==null){res.sendError(404);return;}req.setAttribute("pet",pet);req.setAttribute("images",dao.images(id));}
            catch(NumberFormatException e){res.sendError(400);return;}catch(Exception e){throw new ServletException(e);}
        }
        req.getRequestDispatcher("/WEB-INF/views/pet-form.jsp").forward(req,res);
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");List<String> saved=List.of();
        try{
            User admin=(User)req.getSession().getAttribute("authUser");
            saved=UploadStorage.saveImages(req.getParts(),"pets",8);
            int age=Integer.parseInt(req.getParameter("age"));String petIdValue=req.getParameter("petId");PetDAO dao=new PetDAO();
            if(petIdValue==null||petIdValue.isBlank()){
                dao.createByAdmin(admin.getUserId(),req.getParameter("petName"),req.getParameter("species"),req.getParameter("breed"),req.getParameter("gender"),age,req.getParameter("color"),req.getParameter("description"),req.getParameter("location"),req.getParameter("healthStatus"),req.getParameter("vaccinationStatus"),req.getParameter("intakeType"),saved,req.getRemoteAddr());
            }else{
                dao.updateByAdmin(admin.getUserId(),Integer.parseInt(petIdValue),req.getParameter("petName"),req.getParameter("species"),req.getParameter("breed"),req.getParameter("gender"),age,req.getParameter("color"),req.getParameter("description"),req.getParameter("location"),req.getParameter("healthStatus"),req.getParameter("vaccinationStatus"),req.getParameter("intakeType"),saved,req.getRemoteAddr());
            }
            res.sendRedirect(req.getContextPath()+"/admin/pets?updated=1");
        }catch(Exception e){
            UploadStorage.deleteStored(saved);
            String petIdValue=req.getParameter("petId");
            if(petIdValue!=null&&!petIdValue.isBlank()){
                try{PetDAO dao=new PetDAO();int id=Integer.parseInt(petIdValue);req.setAttribute("pet",dao.getForAdmin(id));req.setAttribute("images",dao.images(id));}
                catch(Exception ignored){ }
            }
            req.setAttribute("error",e.getMessage()==null?"Pet information could not be saved.":e.getMessage());
            req.getRequestDispatcher("/WEB-INF/views/pet-form.jsp").forward(req,res);
        }
    }
}
