package controller;

import entity.User;
import dao.ApplicationDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class DashboardServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        User user=(User)req.getSession().getAttribute("authUser");
        if("ADMIN".equals(user.getRoleName())){res.sendRedirect(req.getContextPath()+"/admin/dashboard");return;}
        try{
            req.setAttribute("applications",new ApplicationDAO().forUser(user.getUserId()));
            req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req,res);
        }catch(Exception e){throw new ServletException(e);}
    }
}
