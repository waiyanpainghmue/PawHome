package controller;
import dao.CommunityDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
public class ContactServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException {
        try{q.setAttribute("siteSettings",new CommunityDAO().settings());}catch(Exception e){throw new ServletException(e);}
        q.getRequestDispatcher("/WEB-INF/views/contact.jsp").forward(q,s);
    }
    @Override protected void doPost(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException {
        q.setCharacterEncoding("UTF-8");
        try{new CommunityDAO().submitContact(q.getParameter("fullName"),q.getParameter("email"),q.getParameter("phone"),q.getParameter("subject"),q.getParameter("message"));s.sendRedirect(q.getContextPath()+"/contact?submitted=1");}
        catch(Exception e){try{q.setAttribute("siteSettings",new CommunityDAO().settings());}catch(Exception ignored){}q.setAttribute("error",e.getMessage());q.getRequestDispatcher("/WEB-INF/views/contact.jsp").forward(q,s);}
    }
}
