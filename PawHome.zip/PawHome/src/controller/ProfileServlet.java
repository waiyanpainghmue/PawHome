package controller;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import service.UploadStorage;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class ProfileServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User sessionUser = session == null ? null : (User) session.getAttribute("authUser");
        if (sessionUser == null) { response.sendRedirect(request.getContextPath() + "/login"); return; }
        try {
            User current = new UserDAO().findById(sessionUser.getUserId());
            if (current == null) { session.invalidate(); response.sendRedirect(request.getContextPath() + "/login"); return; }
            session.setAttribute("authUser", current);
            request.getRequestDispatcher("/WEB-INF/views/profile.jsp").forward(request, response);
        } catch (Exception e) { throw new ServletException("Unable to load profile.", e); }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        User sessionUser = session == null ? null : (User) session.getAttribute("authUser");
        if (sessionUser == null) { response.sendRedirect(request.getContextPath() + "/login"); return; }

        List<String> uploaded = Collections.emptyList();
        boolean profileSaved = false;
        try {
            String name = request.getParameter("fullName");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            if (name == null || name.isBlank() || name.trim().length() > 100 ||
                (phone != null && phone.length() > 30) || (address != null && address.length() > 2000)) {
                throw new IllegalArgumentException("Enter a valid name, phone number and address.");
            }

            UserDAO dao = new UserDAO();
            User current = dao.findById(sessionUser.getUserId());
            if (current == null) throw new IllegalArgumentException("Your account could not be found.");

            Part photo = request.getPart("profileImage");
            uploaded = photo == null ? Collections.emptyList() : UploadStorage.saveImages(Collections.singletonList(photo), "profiles", 1);
            String newImage = uploaded.isEmpty() ? null : uploaded.get(0);

            dao.updateProfile(current.getUserId(), name.trim(), phone == null ? null : phone.trim(),
                address == null ? null : address.trim(), newImage);
            profileSaved = true;

            User updated = dao.findById(current.getUserId());
            if (updated == null) throw new IllegalStateException("Profile was saved but could not be reloaded.");
            session.setAttribute("authUser", updated);

            if (newImage != null && current.getProfileImage() != null && current.getProfileImage().startsWith("media/profiles/")) {
                UploadStorage.deleteStored(Collections.singletonList(current.getProfileImage()));
            }
            response.sendRedirect(request.getContextPath() + "/profile?updated=1");
        } catch (IllegalArgumentException e) {
            if (!profileSaved) UploadStorage.deleteStored(uploaded);
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/profile.jsp").forward(request, response);
        } catch (Exception e) {
            if (!profileSaved) UploadStorage.deleteStored(uploaded);
            request.setAttribute("error", "Profile could not be saved. Check the form and try again.");
            request.getRequestDispatcher("/WEB-INF/views/profile.jsp").forward(request, response);
        }
    }
}
