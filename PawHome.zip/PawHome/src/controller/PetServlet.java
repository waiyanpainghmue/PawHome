package controller;
import dao.PetDAO; import jakarta.servlet.http.*; import jakarta.servlet.*; import java.io.IOException;
public class PetServlet extends HttpServlet { protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{try{req.setAttribute("pets",new PetDAO().find(req.getParameter("q"),req.getParameter("species"),req.getParameter("location")));req.getRequestDispatcher("/WEB-INF/views/pets.jsp").forward(req,res);}catch(Exception e){throw new ServletException(e);}} }
