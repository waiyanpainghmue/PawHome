package controller;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AuthServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        String path=req.getServletPath();
        if(path.equals("/logout")){HttpSession session=req.getSession(false);if(session!=null)session.invalidate();res.sendRedirect(req.getContextPath()+"/home");return;}
        req.getRequestDispatcher(path.equals("/login")?"/WEB-INF/views/login.jsp":"/WEB-INF/views/register.jsp").forward(req,res);
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");
        try {
            UserDAO dao=new UserDAO();
            if(req.getServletPath().equals("/login")){
                User user=dao.login(req.getParameter("email"),req.getParameter("password"));
                if(user==null){req.setAttribute("error","Email or password is incorrect.");req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,res);return;}
                HttpSession old=req.getSession(false);if(old!=null)old.invalidate();req.getSession(true).setAttribute("authUser",user);
                String next=req.getParameter("next");if(next==null||!next.startsWith("/")||next.startsWith("//"))next="/dashboard";
                res.sendRedirect(req.getContextPath()+next);
            } else {
                String name=req.getParameter("fullName"),email=req.getParameter("email"),password=req.getParameter("password"),phone=req.getParameter("phone");
                if(name==null||name.isBlank()||name.trim().length()>100||email==null||!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")||password==null||password.length()<8||phone!=null&&phone.length()>30){
                    req.setAttribute("error","Enter a valid name, email, phone and password with at least 8 characters.");req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,res);return;
                }
                dao.register(name.trim(),email.trim().toLowerCase(),password,phone,req.getParameter("address"),"USER");
                res.sendRedirect(req.getContextPath()+"/login?registered=1");
            }
        } catch(java.sql.SQLIntegrityConstraintViolationException e){req.setAttribute("error","That email address is already registered.");req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req,res);}
        catch(Exception e){throw new ServletException(e);}
    }
}
