package controller;

import dao.CommunityDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

/** Public donation request page. No payment is collected by the website. */
public class DonationServlet extends HttpServlet {
    private final CommunityDAO dao = new CommunityDAO();
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try {
            req.setAttribute("siteSettings", dao.settings());
            req.setAttribute("requestToken", UUID.randomUUID().toString());
            req.setAttribute("todayDate", LocalDate.now(ZoneId.of("Asia/Yangon")).toString());
            req.getRequestDispatcher("/WEB-INF/views/donate.jsp").forward(req,res);
        } catch(Exception e) { throw new ServletException(e); }
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");
        try {
            HttpSession session=req.getSession(false);
            User user=session==null?null:(User)session.getAttribute("authUser");
            Integer userId=user==null?null:user.getUserId();
            String amount=req.getParameter("estimatedAmount");
            String code=dao.submitDonationRequest(userId,req.getParameter("donorName"),req.getParameter("donorPhone"),req.getParameter("donorEmail"),req.getParameter("requestType"),Date.valueOf(req.getParameter("requestedDate")),req.getParameter("purpose"),req.getParameter("message"),amount==null||amount.isBlank()?null:new BigDecimal(amount),req.getParameterValues("mealSlots"),req.getParameter("requestToken"));
            res.sendRedirect(req.getContextPath()+"/donate?submitted="+code);
        } catch(Exception e) {
            req.getSession().setAttribute("donationError",e.getMessage()==null?"Unable to submit the donation request.":e.getMessage());
            res.sendRedirect(req.getContextPath()+"/donate?error=1");
        }
    }
}
