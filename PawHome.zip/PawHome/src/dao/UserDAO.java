package dao;

import entity.User;
import util.DBConnection;
import util.PasswordUtil;
import java.sql.*;

public class UserDAO {
    private static final String USER_SELECT =
        "SELECT u.user_id,u.full_name,u.email,u.phone,u.address,u.preferred_language, " +
        "CASE WHEN r.role_name IN ('RESCUER','SHELTER') THEN 'USER' ELSE r.role_name END role_name, " +
        "NULL verification_status,u.profile_image " +
        "FROM users u JOIN user_roles ur ON ur.user_id=u.user_id " +
        "JOIN roles r ON r.role_id=ur.role_id ";

    public User login(String email, String password) throws Exception {
        String sql = "SELECT u.user_id,u.full_name,u.email,u.phone,u.address,u.preferred_language, " +
            "u.password_hash,CASE WHEN r.role_name IN ('RESCUER','SHELTER') THEN 'USER' ELSE r.role_name END role_name, " +
            "NULL verification_status,u.profile_image " +
            "FROM users u JOIN user_roles ur ON ur.user_id=u.user_id " +
            "JOIN roles r ON r.role_id=ur.role_id " +
            "WHERE u.email=? AND u.account_status='ACTIVE' " +
            "ORDER BY FIELD(r.role_name,'ADMIN','USER','SHELTER','RESCUER') LIMIT 1";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, email);
            try (ResultSet rs = p.executeQuery()) {
                if (rs.next() && PasswordUtil.verify(password, rs.getString("password_hash"))) {
                    return new User(rs.getInt("user_id"), rs.getString("full_name"), rs.getString("email"),
                        rs.getString("phone"), rs.getString("address"), rs.getString("preferred_language"),
                        rs.getString("role_name"), rs.getString("verification_status"), rs.getString("profile_image"));
                }
            }
        }
        return null;
    }

    public boolean register(String name, String email, String password, String phone, String address, String role) throws Exception {
        String hash = PasswordUtil.hash(password);
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int id;
                try (PreparedStatement p = c.prepareStatement(
                    "INSERT INTO users(full_name,email,password_hash,phone,address,preferred_language,account_status) VALUES(?,?,?,?,?,'en','ACTIVE')",
                    Statement.RETURN_GENERATED_KEYS)) {
                    p.setString(1, name); p.setString(2, email); p.setString(3, hash);
                    p.setString(4, phone); p.setString(5, address); p.executeUpdate();
                    try (ResultSet k = p.getGeneratedKeys()) { if (!k.next()) throw new SQLException("Unable to create account."); id = k.getInt(1); }
                }
                try (PreparedStatement p = c.prepareStatement("INSERT INTO user_roles(user_id,role_id) SELECT ?,role_id FROM roles WHERE role_name='USER'")) {
                    p.setInt(1, id);
                    if (p.executeUpdate() != 1) throw new SQLException("USER role not found.");
                }
                c.commit();
                return true;
            } catch (Exception e) { c.rollback(); throw e; }
        }
    }

    public User findById(int id) throws Exception {
        String sql = USER_SELECT + "WHERE u.user_id=? ORDER BY FIELD(r.role_name,'ADMIN','USER','SHELTER','RESCUER') LIMIT 1";
        try (Connection c = DBConnection.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) return new User(r.getInt("user_id"), r.getString("full_name"), r.getString("email"),
                    r.getString("phone"), r.getString("address"), r.getString("preferred_language"),
                    r.getString("role_name"), r.getString("verification_status"), r.getString("profile_image"));
            }
        }
        return null;
    }

    public void updateProfile(int id, String name, String phone, String address, String profileImage) throws Exception {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement check = c.prepareStatement("SELECT 1 FROM users WHERE user_id=? AND account_status='ACTIVE' FOR UPDATE")) {
                    check.setInt(1, id);
                    try (ResultSet r = check.executeQuery()) { if (!r.next()) throw new SQLException("Profile could not be updated."); }
                }
                String sql = "UPDATE users SET full_name=?,phone=?,address=?,profile_image=COALESCE(?,profile_image) WHERE user_id=? AND account_status='ACTIVE'";
                try (PreparedStatement p = c.prepareStatement(sql)) {
                    p.setString(1, name); p.setString(2, phone); p.setString(3, address);
                    p.setString(4, profileImage); p.setInt(5, id); p.executeUpdate();
                }
                c.commit();
            } catch (Exception e) { c.rollback(); throw e; }
        }
    }
}
