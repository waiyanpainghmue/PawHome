package dao;
import util.DBConnection; import java.sql.*; import java.util.*;
public class ApplicationDAO {
 public void apply(int petId,int userId,String phone,String address,String reason,String home,String care,java.math.BigDecimal budget)throws Exception{
  if(phone==null||phone.isBlank()||phone.trim().length()>30||address==null||address.isBlank()||address.trim().length()>2000)throw new IllegalArgumentException("A valid phone number and current address are required.");
  if(reason==null||reason.isBlank()||reason.length()>4000||home==null||home.isBlank()||home.length()>4000||care==null||care.isBlank()||care.length()>4000||budget==null||budget.signum()<0||budget.precision()>10||budget.scale()>2)throw new IllegalArgumentException("Complete all adoption questions with a valid budget (maximum 99,999,999.99 MMK).");
  try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
   try(PreparedStatement lock=c.prepareStatement("SELECT listing_status FROM pets WHERE pet_id=? FOR UPDATE")){lock.setInt(1,petId);try(ResultSet r=lock.executeQuery()){if(!r.next()||!"AVAILABLE".equals(r.getString(1)))throw new SQLException("This pet is not currently available.");}}
   try(PreparedStatement duplicate=c.prepareStatement("SELECT COUNT(*) FROM adoption_applications WHERE pet_id=? AND applicant_user_id=? AND application_status NOT IN ('REJECTED','WITHDRAWN')")){duplicate.setInt(1,petId);duplicate.setInt(2,userId);try(ResultSet r=duplicate.executeQuery()){r.next();if(r.getInt(1)>0)throw new SQLException("You already have an active application for this pet.");}}
   try(PreparedStatement p=c.prepareStatement("INSERT INTO adoption_applications(pet_id,applicant_user_id,applicant_phone,applicant_address,reason,living_environment,care_plan,monthly_budget) VALUES(?,?,?,?,?,?,?,?)")){p.setInt(1,petId);p.setInt(2,userId);p.setString(3,phone.trim());p.setString(4,address.trim());p.setString(5,reason.trim());p.setString(6,home.trim());p.setString(7,care.trim());p.setBigDecimal(8,budget);p.executeUpdate();}c.commit();
  }catch(Exception e){c.rollback();throw e;}}
 }
 public List<Map<String,Object>> forUser(int userId)throws Exception{List<Map<String,Object>> a=new ArrayList<>();String sql="SELECT aa.application_id,aa.application_status,aa.applied_at,p.pet_name,p.species,p.breed,ac.contract_status,ac.contract_number FROM adoption_applications aa JOIN pets p ON p.pet_id=aa.pet_id LEFT JOIN adoption_contracts ac ON ac.application_id=aa.application_id WHERE aa.applicant_user_id=? ORDER BY aa.applied_at DESC";try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setInt(1,userId);try(ResultSet r=p.executeQuery()){while(r.next()){Map<String,Object>m=new HashMap<>();m.put("id",r.getInt(1));m.put("status",r.getString(2));m.put("date",r.getTimestamp(3));m.put("pet",r.getString(4));m.put("species",r.getString(5));m.put("breed",r.getString(6));m.put("contractStatus",r.getString(7));m.put("contractNumber",r.getString(8));a.add(m);}}}return a;}
 public List<Map<String,Object>> all()throws Exception{List<Map<String,Object>>a=new ArrayList<>();String sql="SELECT aa.application_id,aa.application_status,aa.applied_at,p.pet_name,u.full_name,u.email,aa.applicant_phone,aa.applicant_address,aa.reason,aa.living_environment,aa.care_plan,aa.monthly_budget,p.pet_id,p.listing_status,ac.contract_status FROM adoption_applications aa JOIN pets p ON p.pet_id=aa.pet_id JOIN users u ON u.user_id=aa.applicant_user_id LEFT JOIN adoption_contracts ac ON ac.application_id=aa.application_id ORDER BY aa.applied_at DESC";try(Connection c=DBConnection.getConnection();Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){while(r.next()){Map<String,Object>m=new HashMap<>();String[]keys={"id","status","date","pet","name","email","phone","address","reason","home","care","budget","petId","petStatus","contractStatus"};for(int i=0;i<keys.length;i++)m.put(keys[i],r.getObject(i+1));a.add(m);}}return a;}
 public void review(int adminId,int id,String status,String ip)throws Exception{
  if(!Set.of("UNDER_REVIEW","INTERVIEW","MORE_INFO_REQUIRED","APPROVED","REJECTED").contains(status))throw new IllegalArgumentException("Invalid application action");
  try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
   int petId,applicant;String current;
   // Lock order is always Pet -> Application to serialize approvals without cross-application deadlocks.
   try(PreparedStatement p=c.prepareStatement("SELECT pet_id FROM adoption_applications WHERE application_id=?")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Application not found");petId=r.getInt(1);}}
   try(PreparedStatement p=c.prepareStatement("SELECT listing_status FROM pets WHERE pet_id=? FOR UPDATE")){p.setInt(1,petId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Pet not found");if("APPROVED".equals(status)&&!"AVAILABLE".equals(r.getString(1)))throw new SQLException("Pet is no longer available. Another application may have been approved.");}}
   try(PreparedStatement p=c.prepareStatement("SELECT applicant_user_id,application_status FROM adoption_applications WHERE application_id=? FOR UPDATE")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Application not found");applicant=r.getInt(1);current=r.getString(2);}}
   if(!Set.of("SUBMITTED","UNDER_REVIEW","INTERVIEW","MORE_INFO_REQUIRED").contains(current))throw new SQLException("This application can no longer be reviewed.");
   if("APPROVED".equals(status)){
    try(PreparedStatement p=c.prepareStatement("UPDATE pets SET listing_status='RESERVED' WHERE pet_id=? AND listing_status='AVAILABLE'")){p.setInt(1,petId);if(p.executeUpdate()!=1)throw new SQLException("Could not reserve this pet.");}
    try(PreparedStatement p=c.prepareStatement("UPDATE adoption_applications SET application_status='REJECTED' WHERE pet_id=? AND application_id<>? AND application_status IN ('SUBMITTED','UNDER_REVIEW','INTERVIEW','MORE_INFO_REQUIRED')")){p.setInt(1,petId);p.setInt(2,id);p.executeUpdate();}
    try(PreparedStatement p=c.prepareStatement("INSERT INTO adoption_contracts(application_id,contract_number,contract_status) VALUES(?,CONCAT('PH-',DATE_FORMAT(NOW(),'%Y%m%d'),'-',?), 'DRAFT')")){p.setInt(1,id);p.setInt(2,id);p.executeUpdate();}
   }
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_applications SET application_status=? WHERE application_id=?")){p.setString(1,status);p.setInt(2,id);p.executeUpdate();}
   notify(c,applicant,"Adoption application update","Your application #"+id+" is now "+status+".",id);
   audit(c,adminId,"APPLICATION_"+status,"ADOPTION_APPLICATION",id,ip,"Application moved from "+current+" to "+status);c.commit();
  }catch(Exception e){c.rollback();throw e;}}
 }
 public void complete(int adminId,int id,String ip)throws Exception{
  try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
   int petId,applicant;try(PreparedStatement p=c.prepareStatement("SELECT aa.pet_id,aa.applicant_user_id FROM adoption_applications aa WHERE aa.application_id=? AND aa.application_status='APPROVED' FOR UPDATE")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Only an approved application can be completed.");petId=r.getInt(1);applicant=r.getInt(2);}}
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_contracts SET contract_status='COMPLETED',handover_at=NOW() WHERE application_id=? AND contract_status='SIGNED'")){p.setInt(1,id);if(p.executeUpdate()!=1)throw new SQLException("Adoption contract not found or already completed.");}
   try(PreparedStatement p=c.prepareStatement("UPDATE pets SET listing_status='ADOPTED' WHERE pet_id=? AND listing_status='RESERVED'")){p.setInt(1,petId);if(p.executeUpdate()!=1)throw new SQLException("Pet is not reserved by this adoption.");}
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_applications SET application_status='COMPLETED' WHERE application_id=?")){p.setInt(1,id);p.executeUpdate();}
   notify(c,applicant,"Adoption completed","Your PawHome adoption handover has been marked complete.",id);audit(c,adminId,"ADOPTION_COMPLETED","ADOPTION_APPLICATION",id,ip,"Contract and handover completed");c.commit();
  }catch(Exception e){c.rollback();throw e;}}
 }

 public void signContract(int adminId,int id,String ip)throws Exception{
  try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_contracts SET contract_status='SIGNED',signed_at=NOW() WHERE application_id=? AND contract_status IN ('DRAFT','PENDING_SIGNATURE')")){p.setInt(1,id);if(p.executeUpdate()!=1)throw new SQLException("Draft or pending contract not found.");}
   audit(c,adminId,"ADOPTION_CONTRACT_SIGNED","ADOPTION_APPLICATION",id,ip,"Admin recorded that the adoption agreement was signed");c.commit();
  }catch(Exception e){c.rollback();throw e;}}
 }
 public void cancelApproved(int adminId,int id,String ip)throws Exception{
  try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
   int petId,applicant;try(PreparedStatement p=c.prepareStatement("SELECT pet_id,applicant_user_id FROM adoption_applications WHERE application_id=? AND application_status='APPROVED' FOR UPDATE")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Only an approved, not-yet-completed adoption can be cancelled.");petId=r.getInt(1);applicant=r.getInt(2);}}
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_contracts SET contract_status='CANCELLED' WHERE application_id=? AND contract_status IN ('DRAFT','PENDING_SIGNATURE','SIGNED')")){p.setInt(1,id);if(p.executeUpdate()!=1)throw new SQLException("Contract cannot be cancelled at this stage.");}
   try(PreparedStatement p=c.prepareStatement("UPDATE pets SET listing_status='AVAILABLE' WHERE pet_id=? AND listing_status='RESERVED'")){p.setInt(1,petId);if(p.executeUpdate()!=1)throw new SQLException("Pet reservation could not be released.");}
   try(PreparedStatement p=c.prepareStatement("UPDATE adoption_applications SET application_status='WITHDRAWN' WHERE application_id=?")){p.setInt(1,id);p.executeUpdate();}
   notify(c,applicant,"Adoption approval cancelled","The approved adoption application #"+id+" has been cancelled. The pet is available again.",id);audit(c,adminId,"APPROVED_ADOPTION_CANCELLED","ADOPTION_APPLICATION",id,ip,"Reservation released and contract cancelled");c.commit();
  }catch(Exception e){c.rollback();throw e;}}
 }
 public void withdraw(int userId,int id)throws Exception{try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("UPDATE adoption_applications SET application_status='WITHDRAWN' WHERE application_id=? AND applicant_user_id=? AND application_status IN ('SUBMITTED','UNDER_REVIEW','INTERVIEW','MORE_INFO_REQUIRED')")){p.setInt(1,id);p.setInt(2,userId);if(p.executeUpdate()!=1)throw new SQLException("This application cannot be withdrawn at its current stage.");}}
 private void notify(Connection c,int uid,String title,String message,int id)throws SQLException{try(PreparedStatement p=c.prepareStatement("INSERT INTO notifications(user_id,title,message,notification_type,related_entity_type,related_entity_id) VALUES(?,?,?,'ADOPTION','APPLICATION',?)")){p.setInt(1,uid);p.setString(2,title);p.setString(3,message);p.setInt(4,id);p.executeUpdate();}}
 private void audit(Connection c,int uid,String action,String type,int id,String ip,String details)throws SQLException{try(PreparedStatement p=c.prepareStatement("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,ip_address,details) VALUES(?,?,?,?,?,?)")){p.setInt(1,uid);p.setString(2,action);p.setString(3,type);p.setInt(4,id);p.setString(5,ip);p.setString(6,details);p.executeUpdate();}}
}
