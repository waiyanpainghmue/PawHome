package dao;

import entity.Pet;
import util.DBConnection;
import java.sql.*;
import java.util.*;

public class PetDAO {
    private Pet map(ResultSet r) throws SQLException {
        return new Pet(r.getInt("pet_id"),r.getString("pet_name"),r.getString("species"),r.getString("breed"),r.getString("gender"),r.getInt("age"),r.getString("color"),r.getString("description"),r.getString("listing_status"),r.getString("image_path"),r.getString("location"),r.getString("health_status"),r.getString("vaccination_status"),r.getString("intake_type"));
    }
    private static final String BASE = "SELECT p.*, COALESCE(NULLIF(p.rescue_location,''),s.address,'Not recorded') location, (SELECT pi.image_path FROM pet_images pi WHERE pi.pet_id=p.pet_id ORDER BY pi.is_primary DESC,pi.image_id LIMIT 1) image_path FROM pets p LEFT JOIN shelters s ON s.shelter_id=p.shelter_id ";
    public List<Pet> find(String q,String species,String location) throws Exception {
        List<Pet> out=new ArrayList<>(); String sql=BASE+"WHERE p.listing_status='AVAILABLE' AND (?='' OR p.pet_name LIKE ? OR p.breed LIKE ? OR p.description LIKE ?) AND (?='ALL' OR p.species=?) AND (?='' OR COALESCE(NULLIF(p.rescue_location,''),s.address,'') LIKE ?) ORDER BY p.created_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            String term=q==null?"":q.trim(),loc=location==null?"":location.trim(),sp=species==null||species.isBlank()?"ALL":species;
            p.setString(1,term);p.setString(2,"%"+term+"%");p.setString(3,"%"+term+"%");p.setString(4,"%"+term+"%");p.setString(5,sp);p.setString(6,sp);p.setString(7,loc);p.setString(8,"%"+loc+"%");
            try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r));}
        } return out;
    }
    public Pet get(int id) throws Exception {
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(BASE+"WHERE p.pet_id=? AND p.listing_status IN ('AVAILABLE','RESERVED','ADOPTED','CLOSED')")){
            p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}
        }
    }
    /** Admin-only lookup includes unpublished and rejected listings so they can be edited. */
    public Pet getForAdmin(int id) throws Exception {
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(BASE+"WHERE p.pet_id=?")){
            p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}
        }
    }
    public List<Map<String,Object>> images(int id) throws Exception {
        List<Map<String,Object>> out=new ArrayList<>();
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT image_id,image_path,is_primary FROM pet_images WHERE pet_id=? ORDER BY is_primary DESC,image_id")){
            p.setInt(1,id);try(ResultSet r=p.executeQuery()){while(r.next()){Map<String,Object>m=new LinkedHashMap<>();m.put("id",r.getInt(1));m.put("path",r.getString(2));m.put("primary",r.getBoolean(3));out.add(m);}}
        } return out;
    }
    public int createByAdmin(int adminId,String name,String species,String breed,String gender,int age,String color,String description,String location,String health,String vaccination,String intakeType,List<String> images,String ip) throws Exception {
        validate(name,species,gender,age);
        if(location==null||location.isBlank()||location.length()>255)throw new IllegalArgumentException("Enter the animal's current location.");
        if(images==null||images.isEmpty())throw new IllegalArgumentException("Upload at least one clear pet photo.");
        try(Connection c=DBConnection.getConnection()) { c.setAutoCommit(false); try {
            int petId;
            if(!Set.of("RESCUED","SURRENDERED","DONATED","OTHER").contains(intakeType))throw new IllegalArgumentException("Select a valid intake type.");
            String sql="INSERT INTO pets(posted_by_user_id,shelter_id,rescue_location,pet_name,species,breed,gender,age,color,description,health_status,vaccination_status,intake_type,listing_status) VALUES(?,(SELECT shelter_id FROM (SELECT MIN(shelter_id) shelter_id FROM shelters WHERE verification_status='VERIFIED') org),?,?,?,?,?,?,?,?,?,?,?,'AVAILABLE')";
            try(PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
                p.setInt(1,adminId);p.setString(2,location.trim());p.setString(3,name.trim());p.setString(4,species);p.setString(5,clean(breed,100));p.setString(6,gender);p.setInt(7,age);p.setString(8,clean(color,100));p.setString(9,clean(description,5000));p.setString(10,clean(health,100));p.setString(11,clean(vaccination,100));p.setString(12,intakeType);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(!k.next())throw new SQLException("Pet ID was not generated.");petId=k.getInt(1);}
            }
            try(PreparedStatement p=c.prepareStatement("INSERT INTO pet_images(pet_id,image_path,is_primary) VALUES(?,?,?)")){
                for(int i=0;i<images.size();i++){p.setInt(1,petId);p.setString(2,images.get(i));p.setBoolean(3,i==0);p.addBatch();}p.executeBatch();
            }
            audit(c,adminId,petId,ip,"PET_CREATED","New pet listing created");c.commit();return petId;
        } catch(Exception e){c.rollback();throw e;} }
    }
    public void updateByAdmin(int adminId,int petId,String name,String species,String breed,String gender,int age,String color,String description,String location,String health,String vaccination,String intakeType,List<String> images,String ip) throws Exception {
        validate(name,species,gender,age);
        if(location==null||location.isBlank()||location.length()>255)throw new IllegalArgumentException("Enter the animal's current location.");
        if(!Set.of("RESCUED","SURRENDERED","DONATED","OTHER").contains(intakeType))throw new IllegalArgumentException("Select a valid intake type.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String currentStatus;
            try(PreparedStatement check=c.prepareStatement("SELECT listing_status FROM pets WHERE pet_id=? FOR UPDATE")){check.setInt(1,petId);try(ResultSet r=check.executeQuery()){if(!r.next())throw new SQLException("Pet not found.");currentStatus=r.getString(1);}}
            if(Set.of("RESERVED","ADOPTED").contains(currentStatus))throw new SQLException("A reserved or adopted pet cannot be edited.");
            try(PreparedStatement p=c.prepareStatement("UPDATE pets SET rescue_location=?,pet_name=?,species=?,breed=?,gender=?,age=?,color=?,description=?,health_status=?,vaccination_status=?,intake_type=? WHERE pet_id=?")){
                p.setString(1,location.trim());p.setString(2,name.trim());p.setString(3,species);p.setString(4,clean(breed,100));p.setString(5,gender);p.setInt(6,age);p.setString(7,clean(color,100));p.setString(8,clean(description,5000));p.setString(9,clean(health,100));p.setString(10,clean(vaccination,100));p.setString(11,intakeType);p.setInt(12,petId);p.executeUpdate();
            }
            if(images!=null&&!images.isEmpty()){
                try(PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM pet_images WHERE pet_id=?")){p.setInt(1,petId);try(ResultSet r=p.executeQuery()){r.next();if(r.getInt(1)==0){}else try(PreparedStatement clear=c.prepareStatement("UPDATE pet_images SET is_primary=0 WHERE pet_id=?")){clear.setInt(1,petId);clear.executeUpdate();}}}
                try(PreparedStatement p=c.prepareStatement("INSERT INTO pet_images(pet_id,image_path,is_primary) VALUES(?,?,?)")){for(int i=0;i<images.size();i++){p.setInt(1,petId);p.setString(2,images.get(i));p.setBoolean(3,i==0);p.addBatch();}p.executeBatch();}
            }
            audit(c,adminId,petId,ip,"PET_UPDATED","Pet listing updated");c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }
    private void validate(String name,String species,String gender,int age){
        if(name==null||name.isBlank()||name.trim().length()>100)throw new IllegalArgumentException("Enter a pet name (maximum 100 characters).");
        if(!Set.of("DOG","CAT","OTHER").contains(species))throw new IllegalArgumentException("Select a valid species.");
        if(!Set.of("MALE","FEMALE","UNKNOWN").contains(gender))throw new IllegalArgumentException("Select a valid gender.");
        if(age<0||age>50)throw new IllegalArgumentException("Enter a valid age.");
    }
    private String clean(String s,int max){if(s==null)return null;String t=s.trim();if(t.length()>max)throw new IllegalArgumentException("Pet information is too long.");return t;}
    private void audit(Connection c,int adminId,int petId,String ip,String action,String detail)throws SQLException{
        try(PreparedStatement p=c.prepareStatement("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,ip_address,details) VALUES(?,?,?,?,?,?)")){p.setInt(1,adminId);p.setString(2,action);p.setString(3,"PET");p.setInt(4,petId);p.setString(5,ip);p.setString(6,detail);p.executeUpdate();}
    }
}
