package dao;

import util.DBConnection;
import java.sql.*;
import java.util.*;

/** Administrative queries. Every state-changing operation is parameterized and audited. */
public class AdminDAO {
    private Map<String,Object> row(ResultSet r, String... columns) throws SQLException {
        Map<String,Object> m=new LinkedHashMap<>(); for(String c:columns)m.put(c,r.getObject(c)); return m;
    }
    private List<Map<String,Object>> query(String sql, String... columns) throws Exception {
        List<Map<String,Object>> out=new ArrayList<>();
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql); ResultSet r=p.executeQuery()){
            while(r.next())out.add(row(r,columns));
        } return out;
    }
    public Map<String,Long> metrics() throws Exception {
        Map<String,Long> m=new LinkedHashMap<>();
        String[][] q={
            {"Total Users","SELECT COUNT(*) FROM users"},{"Active Users","SELECT COUNT(*) FROM users WHERE account_status='ACTIVE'"},
            {"Inactive / Suspended Users","SELECT COUNT(*) FROM users WHERE account_status<>'ACTIVE'"},{"Total Pets","SELECT COUNT(*) FROM pets"},
            {"Available Pets","SELECT COUNT(*) FROM pets WHERE listing_status='AVAILABLE'"},{"Adoption Applications","SELECT COUNT(*) FROM adoption_applications"},
            {"Pending Applications","SELECT COUNT(*) FROM adoption_applications WHERE application_status IN ('SUBMITTED','UNDER_REVIEW','INTERVIEW','MORE_INFO_REQUIRED')"},
            {"Open Rescue Reports","SELECT COUNT(*) FROM rescue_reports WHERE report_status='PENDING'"},{"Active Rescue Cases","SELECT COUNT(*) FROM rescue_cases WHERE case_status<>'CLOSED'"},
            {"Received Donation Amount (MMK)","SELECT COALESCE(SUM(amount_received),0) FROM donation_receipts WHERE amount_received IS NOT NULL"},
            {"New Donation Requests","SELECT COUNT(*) FROM donation_requests WHERE request_status='NEW'"},
            {"New Contact Messages","SELECT COUNT(*) FROM contact_messages WHERE message_status='NEW'"}
        };
        try(Connection c=DBConnection.getConnection()) { for(String[] item:q)try(Statement s=c.createStatement();ResultSet r=s.executeQuery(item[1])){r.next();m.put(item[0],r.getLong(1));} }
        return m;
    }
    public List<Map<String,Object>> users(String search,String role) throws Exception {
        String sql="SELECT u.user_id,u.full_name,u.email,u.phone,u.address,u.account_status,u.created_at, GROUP_CONCAT(DISTINCT ro.role_name ORDER BY ro.role_name SEPARATOR ', ') roles FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.user_id LEFT JOIN roles ro ON ro.role_id=ur.role_id WHERE (?='' OR u.full_name LIKE ? OR u.email LIKE ?) AND (?='ALL' OR EXISTS(SELECT 1 FROM user_roles x JOIN roles z ON z.role_id=x.role_id WHERE x.user_id=u.user_id AND z.role_name=?)) GROUP BY u.user_id ORDER BY u.created_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){String s=search==null?"":search.trim();p.setString(1,s);p.setString(2,"%"+s+"%");p.setString(3,"%"+s+"%");p.setString(4,role==null?"ALL":role);p.setString(5,role==null?"ALL":role);List<Map<String,Object>> out=new ArrayList<>();try(ResultSet r=p.executeQuery()){while(r.next())out.add(row(r,"user_id","full_name","email","phone","address","account_status","created_at","roles"));}return out;}
    }
    public void setUserStatus(int adminId,int userId,String status,String ip) throws Exception {
        if(!Set.of("ACTIVE","INACTIVE","SUSPENDED").contains(status))throw new IllegalArgumentException("Invalid account status");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String current;
            try(PreparedStatement p=c.prepareStatement("SELECT account_status FROM users WHERE user_id=? FOR UPDATE")){p.setInt(1,userId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("User not found");current=r.getString(1);}}
            if(current.equals(status)){c.commit();return;}
            if(!"ACTIVE".equals(status)){
                // Serialize administrator deactivation checks so two admins cannot deactivate each other concurrently.
                try(PreparedStatement roleLock=c.prepareStatement("SELECT role_id FROM roles WHERE role_name='ADMIN' FOR UPDATE")){try(ResultSet locked=roleLock.executeQuery()){if(!locked.next())throw new SQLException("ADMIN role is missing.");}}
                try(PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM users u JOIN user_roles ur ON ur.user_id=u.user_id JOIN roles r ON r.role_id=ur.role_id WHERE u.account_status='ACTIVE' AND r.role_name='ADMIN' AND u.user_id=?")){p.setInt(1,userId);try(ResultSet r=p.executeQuery()){r.next();if(r.getInt(1)>0){try(Statement a=c.createStatement();ResultSet x=a.executeQuery("SELECT COUNT(DISTINCT u.user_id) FROM users u JOIN user_roles ur ON ur.user_id=u.user_id JOIN roles ro ON ro.role_id=ur.role_id WHERE u.account_status='ACTIVE' AND ro.role_name='ADMIN'")){x.next();if(x.getInt(1)<=1)throw new SQLException("The last active administrator cannot be deactivated.");}}}}
            }
            try(PreparedStatement p=c.prepareStatement("UPDATE users SET account_status=? WHERE user_id=?")){p.setString(1,status);p.setInt(2,userId);p.executeUpdate();}
            audit(c,adminId,"USER_STATUS_CHANGED","USER",userId,ip,"Account status changed to "+status);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }
    public List<Map<String,Object>> pets(String search,String species,String status) throws Exception {
        String sql="SELECT p.pet_id,p.pet_name,p.species,p.breed,p.listing_status,p.created_at,p.age,p.gender,p.color,p.description,p.health_status,p.vaccination_status,p.intake_type,COALESCE(NULLIF(p.rescue_location,''),s.address,'Not recorded') location,(SELECT pi.image_path FROM pet_images pi WHERE pi.pet_id=p.pet_id ORDER BY pi.is_primary DESC,pi.image_id LIMIT 1) image_path FROM pets p JOIN users u ON u.user_id=p.posted_by_user_id LEFT JOIN shelters s ON s.shelter_id=p.shelter_id WHERE (?='' OR p.pet_name LIKE ? OR p.breed LIKE ?) AND (?='ALL' OR p.species=?) AND (?='ALL' OR p.listing_status=?) ORDER BY p.created_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){String s=search==null?"":search.trim();p.setString(1,s);p.setString(2,"%"+s+"%");p.setString(3,"%"+s+"%");p.setString(4,species==null?"ALL":species);p.setString(5,species==null?"ALL":species);p.setString(6,status==null?"ALL":status);p.setString(7,status==null?"ALL":status);List<Map<String,Object>> out=new ArrayList<>();try(ResultSet r=p.executeQuery()){while(r.next())out.add(row(r,"pet_id","pet_name","species","breed","listing_status","created_at","age","gender","color","description","health_status","vaccination_status","intake_type","location","image_path"));}return out;}
    }
    public void setPetStatus(int adminId,int petId,String status,String ip) throws Exception {
        if(!Set.of("AVAILABLE","REJECTED","CLOSED").contains(status))throw new IllegalArgumentException("Invalid listing action");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String current;
            try(PreparedStatement p=c.prepareStatement("SELECT listing_status FROM pets WHERE pet_id=? FOR UPDATE")){p.setInt(1,petId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Pet not found");current=r.getString(1);}}
            if(Set.of("RESERVED","ADOPTED").contains(current))throw new SQLException("A reserved or adopted pet cannot be changed from this listing action.");
            if(current.equals(status)){c.commit();return;}
            if(!Set.of("DRAFT","PENDING","AVAILABLE","REJECTED","CLOSED").contains(current))throw new SQLException("Pet status cannot be changed from "+current);
            try(PreparedStatement p=c.prepareStatement("UPDATE pets SET listing_status=? WHERE pet_id=?")){p.setString(1,status);p.setInt(2,petId);p.executeUpdate();}
            audit(c,adminId,"PET_STATUS_CHANGED","PET",petId,ip,"Listing status changed to "+status);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }
    public List<Map<String,Object>> donations() throws Exception {return query("SELECT d.donation_id,COALESCE(NULLIF(d.donor_name,''),u.full_name,'Anonymous donor') donor,COALESCE(u.email,'') email,COALESCE(d.donor_phone,u.phone,'') phone,c.title campaign,d.amount,d.donation_status,d.donated_at,d.donation_date,v.full_name verifier,d.verified_at,d.show_public,d.donor_note FROM donations d LEFT JOIN users u ON u.user_id=d.donor_user_id JOIN donation_campaigns c ON c.campaign_id=d.campaign_id LEFT JOIN users v ON v.user_id=d.verified_by_user_id ORDER BY d.donated_at DESC","donation_id","donor","email","phone","campaign","amount","donation_status","donated_at","donation_date","verifier","verified_at","show_public","donor_note");}
    public void setDonationStatus(int adminId,int donationId,String status,String ip) throws Exception {
        if(!Set.of("VERIFIED","REJECTED").contains(status))throw new IllegalArgumentException("Invalid donation status");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try(PreparedStatement p=c.prepareStatement("UPDATE donations SET donation_status=?,verified_by_user_id=?,verified_at=NOW() WHERE donation_id=? AND donation_status='PENDING'")){p.setString(1,status);p.setInt(2,adminId);p.setInt(3,donationId);if(p.executeUpdate()!=1)throw new SQLException("Donation was already reviewed or does not exist");audit(c,adminId,"DONATION_"+status,"DONATION",donationId,ip,"Donation marked "+status);c.commit();}catch(Exception e){c.rollback();throw e;}}
    }
    public List<Map<String,Object>> rescueReports() throws Exception {return query("SELECT rr.rescue_report_id,rr.location,rr.animal_condition,rr.description,rr.report_status,rr.reported_at,COALESCE(NULLIF(rr.reporter_name,''),u.full_name,'Website visitor') reporter,rr.reporter_phone,rr.image_path FROM rescue_reports rr LEFT JOIN users u ON u.user_id=rr.reporter_user_id ORDER BY rr.reported_at DESC","rescue_report_id","location","animal_condition","description","report_status","reported_at","reporter","reporter_phone","image_path");}
    public void reviewRescueReport(int adminId,int reportId,String status,String ip) throws Exception {
        if(!Set.of("VERIFIED","REJECTED").contains(status))throw new IllegalArgumentException("Invalid report status");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try(PreparedStatement p=c.prepareStatement("UPDATE rescue_reports SET report_status=? WHERE rescue_report_id=? AND report_status='PENDING'")){p.setString(1,status);p.setInt(2,reportId);if(p.executeUpdate()!=1)throw new SQLException("Report is already reviewed");if("VERIFIED".equals(status))try(PreparedStatement x=c.prepareStatement("INSERT INTO rescue_cases(rescue_report_id,case_status) VALUES(?,'OPEN')")){x.setInt(1,reportId);x.executeUpdate();}audit(c,adminId,"RESCUE_REPORT_"+status,"RESCUE_REPORT",reportId,ip,"Report reviewed");c.commit();}catch(Exception e){c.rollback();throw e;}}
    }
    public List<Map<String,Object>> rescueCases() throws Exception {return query("SELECT rc.rescue_case_id,rc.case_status,rr.location,rr.animal_condition,rc.created_at FROM rescue_cases rc JOIN rescue_reports rr ON rr.rescue_report_id=rc.rescue_report_id ORDER BY rc.created_at DESC","rescue_case_id","case_status","location","animal_condition","created_at");}
    public void setRescueCaseStatus(int adminId,int caseId,String status,String ip) throws Exception {
        if(!Set.of("OPEN","IN_PROGRESS","RESCUED","MEDICAL_CARE","SHELTERED","READY_FOR_ADOPTION","CLOSED").contains(status))throw new IllegalArgumentException("Invalid rescue case status.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String current;
            try(PreparedStatement p=c.prepareStatement("SELECT case_status FROM rescue_cases WHERE rescue_case_id=? FOR UPDATE")){p.setInt(1,caseId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Rescue case not found.");current=r.getString(1);}}
            if("CLOSED".equals(current)&&!"CLOSED".equals(status))throw new SQLException("A closed rescue case cannot be reopened from this screen.");
            if(current.equals(status)){c.commit();return;}
            try(PreparedStatement p=c.prepareStatement("UPDATE rescue_cases SET case_status=? WHERE rescue_case_id=?")){p.setString(1,status);p.setInt(2,caseId);p.executeUpdate();}
            audit(c,adminId,"RESCUE_CASE_STATUS_CHANGED","RESCUE_CASE",caseId,ip,"Case status changed to "+status);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }
    public List<Map<String,Object>> lostFoundReports() throws Exception {return query("SELECT l.report_id,l.report_type,l.pet_name,l.species,l.breed,l.color,l.gender,l.location,l.incident_date,l.description,l.contact_information,l.report_status,l.created_at,u.full_name reporter FROM lost_found_reports l JOIN users u ON u.user_id=l.reporter_user_id ORDER BY l.created_at DESC","report_id","report_type","pet_name","species","breed","color","gender","location","incident_date","description","contact_information","report_status","created_at","reporter");}
    public void reviewLostFound(int adminId,int reportId,String status,String ip) throws Exception {
        if(!Set.of("ACTIVE","REJECTED","REUNITED","CLOSED").contains(status))throw new IllegalArgumentException("Invalid lost & found status");
        String allowed=("ACTIVE".equals(status)||"REJECTED".equals(status))?"PENDING":"ACTIVE";
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try(PreparedStatement p=c.prepareStatement("UPDATE lost_found_reports SET report_status=? WHERE report_id=? AND report_status=?")){p.setString(1,status);p.setInt(2,reportId);p.setString(3,allowed);if(p.executeUpdate()!=1)throw new SQLException("Report is not in a state that can be changed to "+status);audit(c,adminId,"LOST_FOUND_"+status,"LOST_FOUND_REPORT",reportId,ip,"Lost & Found report reviewed");c.commit();}catch(Exception e){c.rollback();throw e;}}
    }
    private void audit(Connection c,int uid,String action,String type,int id,String ip,String details)throws SQLException {try(PreparedStatement p=c.prepareStatement("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,ip_address,details) VALUES(?,?,?,?,?,?)")){p.setInt(1,uid);p.setString(2,action);p.setString(3,type);p.setInt(4,id);p.setString(5,ip);p.setString(6,details);p.executeUpdate();}}
}
