package dao;

import util.DBConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

/** Public contact, settings, donation request and receipt data access. */
public class CommunityDAO {
    private Map<String,Object> map(ResultSet r, String... keys) throws SQLException {
        Map<String,Object> out = new LinkedHashMap<>();
        for (String key : keys) out.put(key, r.getObject(key));
        return out;
    }
    private List<Map<String,Object>> query(String sql, String... keys) throws Exception {
        List<Map<String,Object>> out = new ArrayList<>();
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql); ResultSet r=p.executeQuery()) {
            while (r.next()) out.add(map(r, keys));
        }
        return out;
    }

    /** Executes a single-date query; the first SQL placeholder is always bound. */
    private List<Map<String,Object>> query(String sql, java.sql.Date date, String... keys) throws Exception {
        if (date == null) throw new IllegalArgumentException("A query date is required.");
        List<Map<String,Object>> out = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setDate(1, date);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) out.add(map(r, keys));
            }
        }
        return out;
    }
    public Map<String,String> settings() throws Exception {
        Map<String,String> out = new LinkedHashMap<>();
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("SELECT setting_key,setting_value FROM site_settings"); ResultSet r=p.executeQuery()) {
            while (r.next()) out.put(r.getString(1), r.getString(2));
        }
        return out;
    }
    public List<Map<String,Object>> categories() throws Exception {
        return query("SELECT category_id,category_name,category_code,description FROM donation_categories WHERE is_active=1 ORDER BY display_order,category_id", "category_id","category_name","category_code","description");
    }
    public List<Map<String,Object>> adminCampaigns() throws Exception {
        return query("SELECT c.campaign_id,c.title,c.description,c.goal_amount,c.campaign_type,c.occasion_name,c.start_date,c.end_date,c.campaign_status,COALESCE(cat.category_name,'General support') category_name,COALESCE(SUM(CASE WHEN d.donation_status='VERIFIED' THEN d.amount ELSE 0 END),0) verified_total FROM donation_campaigns c LEFT JOIN donation_categories cat ON cat.category_id=c.category_id LEFT JOIN donations d ON d.campaign_id=c.campaign_id GROUP BY c.campaign_id,c.title,c.description,c.goal_amount,c.campaign_type,c.occasion_name,c.start_date,c.end_date,c.campaign_status,cat.category_name ORDER BY c.created_at DESC", "campaign_id","title","description","goal_amount","campaign_type","occasion_name","start_date","end_date","campaign_status","category_name","verified_total");
    }
    public List<Map<String,Object>> donationEntryCampaigns() throws Exception {
        return query("SELECT campaign_id,title,campaign_status,start_date,end_date FROM donation_campaigns WHERE campaign_status IN ('ACTIVE','COMPLETED') ORDER BY CASE campaign_status WHEN 'ACTIVE' THEN 0 ELSE 1 END,created_at DESC", "campaign_id","title","campaign_status","start_date","end_date");
    }
    public List<Map<String,Object>> campaigns(java.sql.Date today) throws Exception {
        List<Map<String,Object>> out = new ArrayList<>();
        String sql="SELECT c.campaign_id,c.title,c.description,c.goal_amount,c.campaign_type,c.occasion_name,c.start_date,c.end_date,COALESCE(cat.category_name,'General support') category_name,COALESCE(SUM(CASE WHEN d.donation_status='VERIFIED' THEN d.amount ELSE 0 END),0) verified_total FROM donation_campaigns c LEFT JOIN donation_categories cat ON cat.category_id=c.category_id LEFT JOIN donations d ON d.campaign_id=c.campaign_id WHERE c.campaign_status='ACTIVE' AND (c.start_date IS NULL OR c.start_date<=?) AND (c.end_date IS NULL OR c.end_date>=?) GROUP BY c.campaign_id,c.title,c.description,c.goal_amount,c.campaign_type,c.occasion_name,c.start_date,c.end_date,cat.category_name ORDER BY c.start_date DESC,c.created_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setDate(1,today);p.setDate(2,today);try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r,"campaign_id","title","description","goal_amount","campaign_type","occasion_name","start_date","end_date","category_name","verified_total"));}}
        return out;
    }
    public List<Map<String,Object>> todaySponsors(java.sql.Date today) throws Exception {
        List<Map<String,Object>> out = new ArrayList<>();
        String sql="SELECT d.donor_name,d.donor_note,d.amount,d.donated_at,c.title campaign_title,cat.category_name FROM donations d JOIN donation_campaigns c ON c.campaign_id=d.campaign_id LEFT JOIN donation_categories cat ON cat.category_id=c.category_id WHERE d.donation_status='VERIFIED' AND d.show_public=1 AND c.campaign_type IN ('DAILY_MEAL','SPECIAL_OCCASION') AND d.donation_date=? ORDER BY d.donated_at";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setDate(1,today);try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r,"donor_name","donor_note","amount","donated_at","campaign_title","category_name"));}}
        return out;
    }
    public List<Map<String,Object>> recentSponsors() throws Exception {
        return query("SELECT d.donor_name,d.donor_note,d.amount,d.donated_at,c.title campaign_title,cat.category_name FROM donations d JOIN donation_campaigns c ON c.campaign_id=d.campaign_id LEFT JOIN donation_categories cat ON cat.category_id=c.category_id WHERE d.donation_status='VERIFIED' AND d.show_public=1 ORDER BY d.donation_date DESC,d.donated_at DESC LIMIT 8", "donor_name","donor_note","amount","donated_at","campaign_title","category_name");
    }
    public void submitVolunteer(String name,String phone,String email,String township,String interests,String availability,String message) throws Exception {
        require(name,100,"Name"); require(phone,30,"Phone number"); require(email,150,"Email"); if(!email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))throw new IllegalArgumentException("Enter a valid email address.");
        if (interests==null || interests.isBlank() || interests.length()>1000) throw new IllegalArgumentException("Choose or describe at least one volunteer activity.");
        if (township!=null && township.trim().length()>150) throw new IllegalArgumentException("Township / city is too long.");
        if (availability!=null && availability.trim().length()>500) throw new IllegalArgumentException("Availability is too long.");
        if (message!=null && message.length()>4000) throw new IllegalArgumentException("Message is too long.");
        String sql="INSERT INTO volunteer_applications(full_name,phone,email,township,interests,availability,message,application_status) VALUES(?,?,?,?,?,?,?,'PENDING')";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,name.trim());p.setString(2,phone.trim());p.setString(3,email.trim().toLowerCase());p.setString(4,township==null?null:township.trim());p.setString(5,interests.trim());p.setString(6,availability==null?null:availability.trim());p.setString(7,message==null?null:message.trim());p.executeUpdate();
        }
    }
    public void submitContact(String name,String email,String phone,String subject,String message) throws Exception {
        require(name,100,"Name"); require(email,150,"Email"); if(!email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))throw new IllegalArgumentException("Enter a valid email address.");
        if (phone!=null && phone.trim().length()>30) throw new IllegalArgumentException("Phone number is too long.");
        if (subject==null || subject.isBlank() || subject.length()>180 || message==null || message.isBlank() || message.length()>5000) throw new IllegalArgumentException("Enter a subject and message.");
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("INSERT INTO contact_messages(full_name,email,phone,subject,message,message_status) VALUES(?,?,?,?,?,'NEW')")) {
            p.setString(1,name.trim());p.setString(2,email.trim().toLowerCase());p.setString(3,phone==null?null:phone.trim());p.setString(4,subject.trim());p.setString(5,message.trim());p.executeUpdate();
        }
    }
    public List<Map<String,Object>> volunteers() throws Exception {
        return query("SELECT application_id,full_name,phone,email,township,interests,availability,message,application_status,created_at FROM volunteer_applications ORDER BY created_at DESC", "application_id","full_name","phone","email","township","interests","availability","message","application_status","created_at");
    }
    public List<Map<String,Object>> messages() throws Exception {
        return query("SELECT message_id,full_name,email,phone,subject,message,message_status,created_at FROM contact_messages ORDER BY created_at DESC", "message_id","full_name","email","phone","subject","message","message_status","created_at");
    }
    public void updateVolunteer(int adminId,int id,String status,String ip) throws Exception {
        if (!Set.of("REVIEWING","ACCEPTED","REJECTED","COMPLETED").contains(status)) throw new IllegalArgumentException("Invalid volunteer status.");
        updateAndAudit("volunteer_applications","application_id","UPDATE volunteer_applications SET application_status=?,reviewed_by_user_id=?,reviewed_at=NOW() WHERE application_id=?", status, adminId, id, "VOLUNTEER_"+status, "VOLUNTEER_APPLICATION", ip);
    }
    public void updateMessage(int adminId,int id,String status,String ip) throws Exception {
        if (!Set.of("READ","REPLIED","CLOSED").contains(status)) throw new IllegalArgumentException("Invalid message status.");
        updateAndAudit("contact_messages","message_id","UPDATE contact_messages SET message_status=?,handled_by_user_id=?,handled_at=NOW() WHERE message_id=?", status, adminId, id, "CONTACT_"+status, "CONTACT_MESSAGE", ip);
    }
    private void updateAndAudit(String table,String idColumn,String sql,String status,int adminId,int id,String action,String type,String ip) throws Exception {
        try (Connection c=DBConnection.getConnection()) { c.setAutoCommit(false); try {
            try(PreparedStatement check=c.prepareStatement("SELECT 1 FROM "+table+" WHERE "+idColumn+"=? FOR UPDATE")){check.setInt(1,id);try(ResultSet r=check.executeQuery()){if(!r.next())throw new SQLException("Record not found.");}}
            try (PreparedStatement p=c.prepareStatement(sql)) { p.setString(1,status);p.setInt(2,adminId);p.setInt(3,id);p.executeUpdate(); }
            audit(c,adminId,action,type,id,ip,status);c.commit();
        } catch(Exception e){c.rollback();throw e;} }
    }
    public void saveSettings(int adminId,Map<String,String> values,String ip) throws Exception {
        Set<String> allowed=Set.of("contact_phone","contact_email","facebook_url","messenger_url","instagram_url","organization_address","office_hours","organization_name");
        try (Connection c=DBConnection.getConnection()) { c.setAutoCommit(false); try {
            for (Map.Entry<String,String> e:values.entrySet()) {
                if (!allowed.contains(e.getKey())) continue;
                String value=e.getValue()==null?"":e.getValue().trim(); if(value.length()>1000)throw new IllegalArgumentException("A website setting is too long.");
                if(Set.of("facebook_url","messenger_url","instagram_url").contains(e.getKey()) && !value.isEmpty() && !value.matches("https://[^\\s]+"))throw new IllegalArgumentException("Social media links must begin with https://");
                if("contact_email".equals(e.getKey()) && !value.isEmpty() && !value.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))throw new IllegalArgumentException("Enter a valid contact email.");
                try (PreparedStatement p=c.prepareStatement("INSERT INTO site_settings(setting_key,setting_value,updated_by_user_id,updated_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_by_user_id=VALUES(updated_by_user_id),updated_at=NOW()")) {p.setString(1,e.getKey());p.setString(2,value);p.setInt(3,adminId);p.executeUpdate();}
            }
            audit(c,adminId,"SITE_SETTINGS_UPDATED","SITE_SETTINGS",0,ip,"Public contact information updated");c.commit();
        } catch(Exception e){c.rollback();throw e;} }
    }
    public void createCampaign(int adminId,int categoryId,String title,String description,BigDecimal goal,String type,String occasion,java.sql.Date start,java.sql.Date end,String ip) throws Exception {
        require(title,200,"Campaign title"); if(description!=null&&description.length()>4000)throw new IllegalArgumentException("Campaign description is too long."); if(occasion!=null&&occasion.length()>150)throw new IllegalArgumentException("Occasion name is too long.");
        if(goal==null||goal.signum()<=0||goal.precision()>12||goal.scale()>2)throw new IllegalArgumentException("Enter a valid campaign target amount.");
        if(!Set.of("GENERAL","DAILY_MEAL","SPECIAL_OCCASION").contains(type))throw new IllegalArgumentException("Select a valid campaign type.");
        if(start!=null&&end!=null&&end.before(start))throw new IllegalArgumentException("End date must not be earlier than start date.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            try(PreparedStatement p=c.prepareStatement("INSERT INTO donation_campaigns(created_by_user_id,title,description,goal_amount,campaign_status,start_date,end_date,category_id,campaign_type,occasion_name) VALUES(?,?,?,?,'ACTIVE',?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){
                p.setInt(1,adminId);p.setString(2,title.trim());p.setString(3,description==null?null:description.trim());p.setBigDecimal(4,goal);if(start==null)p.setNull(5,Types.DATE);else p.setDate(5,start);if(end==null)p.setNull(6,Types.DATE);else p.setDate(6,end);if(categoryId<=0)p.setNull(7,Types.INTEGER);else p.setInt(7,categoryId);p.setString(8,type);p.setString(9,occasion==null?null:occasion.trim());p.executeUpdate();
                try(ResultSet k=p.getGeneratedKeys()){k.next();audit(c,adminId,"DONATION_CAMPAIGN_CREATED","DONATION_CAMPAIGN",k.getInt(1),ip,title.trim());}
            }c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }
    public void recordDonation(int adminId,int campaignId,String donorName,String donorPhone,BigDecimal amount,java.sql.Date donationDate,boolean showPublic,String note,String entryToken,String ip) throws Exception {
        require(donorName,100,"Donor name");
        if(entryToken==null||!entryToken.matches("[0-9a-fA-F-]{36}"))throw new IllegalArgumentException("Refresh the donation form and submit it again."); if(donorPhone!=null&&donorPhone.length()>30)throw new IllegalArgumentException("Donor phone number is too long."); if(note!=null&&note.length()>500)throw new IllegalArgumentException("Donor note is too long.");
        if(amount==null||amount.signum()<=0||amount.precision()>12||amount.scale()>2)throw new IllegalArgumentException("Enter the actual amount received.");
        if(donationDate==null)throw new IllegalArgumentException("Select the actual donation date.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            int id;
            try(PreparedStatement p=c.prepareStatement("INSERT INTO donations(campaign_id,donor_user_id,donor_name,donor_phone,donor_note,show_public,amount,donation_status,verified_by_user_id,verified_at,donated_at,donation_date,admin_entry_token) SELECT ?,NULL,?,?,?,?,?,'VERIFIED',?,NOW(),NOW(),?,? FROM donation_campaigns WHERE campaign_id=? AND campaign_status IN ('ACTIVE','COMPLETED') AND (start_date IS NULL OR start_date<=?) AND (end_date IS NULL OR end_date>=?)",Statement.RETURN_GENERATED_KEYS)){
                p.setInt(1,campaignId);p.setString(2,donorName.trim());p.setString(3,donorPhone==null?null:donorPhone.trim());p.setString(4,note==null?null:note.trim());p.setBoolean(5,showPublic);p.setBigDecimal(6,amount);p.setInt(7,adminId);p.setDate(8,donationDate);p.setString(9,entryToken);p.setInt(10,campaignId);p.setDate(11,donationDate);p.setDate(12,donationDate);
                try { if(p.executeUpdate()!=1)throw new SQLException("Campaign does not accept donations for the selected date."); }
                catch(SQLIntegrityConstraintViolationException duplicate){
                    try(PreparedStatement existing=c.prepareStatement("SELECT donation_id FROM donations WHERE admin_entry_token=?")){existing.setString(1,entryToken);try(ResultSet r=existing.executeQuery()){if(r.next()){c.commit();return;}else throw duplicate;}}
                }
                try(ResultSet k=p.getGeneratedKeys()){if(!k.next())throw new SQLException("Donation record was not created.");id=k.getInt(1);}
            }
            audit(c,adminId,"DONATION_RECEIVED","DONATION",id,ip,"Recorded donation from "+donorName.trim()+" amount "+amount);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }

    public void updateCampaignStatus(int adminId,int campaignId,String status,String ip) throws Exception {
        if (!Set.of("DRAFT","PENDING","ACTIVE","COMPLETED","CANCELLED").contains(status)) throw new IllegalArgumentException("Invalid campaign status.");
        try (Connection c=DBConnection.getConnection()) { c.setAutoCommit(false); try {
            String current;
            try(PreparedStatement check=c.prepareStatement("SELECT campaign_status FROM donation_campaigns WHERE campaign_id=? FOR UPDATE")){check.setInt(1,campaignId);try(ResultSet r=check.executeQuery()){if(!r.next())throw new SQLException("Campaign not found.");current=r.getString(1);}}
            if(current.equals(status)){c.commit();return;}
            try (PreparedStatement p=c.prepareStatement("UPDATE donation_campaigns SET campaign_status=? WHERE campaign_id=?")) {
                p.setString(1,status); p.setInt(2,campaignId); p.executeUpdate();
            }
            audit(c,adminId,"DONATION_CAMPAIGN_"+status,"DONATION_CAMPAIGN",campaignId,ip,"Campaign status changed from "+current+" to "+status);
            c.commit();
        } catch(Exception e) { c.rollback(); throw e; } }
    }

    /** Public donation request. Meal slots are independent, optional selections. */
    public String submitDonationRequest(Integer userId, String name, String phone, String email,
            String type, java.sql.Date requestedDate, String purpose, String message,
            BigDecimal estimatedAmount, String[] mealSlots, String requestToken) throws Exception {
        require(name,100,"Name"); require(phone,30,"Phone number");
        if (email != null && !email.isBlank() && (email.length()>150 || !email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))) throw new IllegalArgumentException("Enter a valid email address.");
        if (!Set.of("MEAL","MEDICAL_CARE","SUPPLIES","GENERAL_SUPPORT").contains(type)) throw new IllegalArgumentException("Choose a valid donation purpose.");
        if (requestedDate == null) throw new IllegalArgumentException("Choose the date you would like to support.");
        if (requestedDate.toLocalDate().isBefore(java.time.LocalDate.now(java.time.ZoneId.of("Asia/Yangon")))) throw new IllegalArgumentException("Choose today or a future date.");
        if (purpose != null && purpose.length()>180) throw new IllegalArgumentException("Donation purpose is too long.");
        if (!"MEAL".equals(type) && (purpose==null || purpose.isBlank())) throw new IllegalArgumentException("Describe the medical care, supplies or support you would like to help with.");
        if (message == null || message.isBlank() || message.length()>3000) throw new IllegalArgumentException("Please tell us a little about your donation.");
        if (estimatedAmount != null && (estimatedAmount.signum()<=0 || estimatedAmount.precision()>12 || estimatedAmount.scale()>2)) throw new IllegalArgumentException("Enter a valid estimated amount.");
        if (requestToken == null || !requestToken.matches("[0-9a-fA-F-]{36}")) throw new IllegalArgumentException("Refresh the form and try again.");
        Set<String> slots = new LinkedHashSet<>();
        if ("MEAL".equals(type)) {
            if (mealSlots == null || mealSlots.length==0) throw new IllegalArgumentException("Choose at least one meal: breakfast, lunch or dinner.");
            for (String slot : mealSlots) { if (!Set.of("BREAKFAST","LUNCH","DINNER").contains(slot)) throw new IllegalArgumentException("Invalid meal selection."); slots.add(slot); }
        } else if (mealSlots != null && mealSlots.length>0) throw new IllegalArgumentException("Meal selections are only for meal sponsorship.");
        String requestCode="PH-DON-"+UUID.randomUUID().toString().substring(0,8).toUpperCase(Locale.ROOT);
        try(Connection c=DBConnection.getConnection()) { c.setAutoCommit(false); try {
            int id;
            try(PreparedStatement p=c.prepareStatement("INSERT INTO donation_requests(request_code,donor_user_id,donor_name,donor_phone,donor_email,request_type,requested_date,purpose,request_message,estimated_amount,request_status,request_token) VALUES(?,?,?,?,?,?,?,?,?,?,'NEW',?)",Statement.RETURN_GENERATED_KEYS)) {
                p.setString(1,requestCode); if(userId==null)p.setNull(2,Types.INTEGER);else p.setInt(2,userId);
                p.setString(3,name.trim());p.setString(4,phone.trim());if(email==null||email.isBlank())p.setNull(5,Types.VARCHAR);else p.setString(5,email.trim().toLowerCase(Locale.ROOT));
                p.setString(6,type);p.setDate(7,requestedDate);if(purpose==null||purpose.isBlank())p.setNull(8,Types.VARCHAR);else p.setString(8,purpose.trim());p.setString(9,message.trim());if(estimatedAmount==null)p.setNull(10,Types.DECIMAL);else p.setBigDecimal(10,estimatedAmount);p.setString(11,requestToken);p.executeUpdate();
                try(ResultSet k=p.getGeneratedKeys()){if(!k.next())throw new SQLException("Donation request was not created.");id=k.getInt(1);}
            }
            if(!slots.isEmpty()) try(PreparedStatement p=c.prepareStatement("INSERT INTO donation_request_meals(request_id,meal_date,meal_slot,meal_status) VALUES(?,?,?,'REQUESTED')")) {
                for(String slot:slots){p.setInt(1,id);p.setDate(2,requestedDate);p.setString(3,slot);p.addBatch();} p.executeBatch();
            }
            c.commit(); return requestCode;
        } catch(SQLIntegrityConstraintViolationException duplicate) {
            c.rollback();
            try(PreparedStatement p=c.prepareStatement("SELECT request_code FROM donation_requests WHERE request_token=?")){p.setString(1,requestToken);try(ResultSet r=p.executeQuery()){if(r.next())return r.getString(1);}}
            throw duplicate;
        } catch(Exception e){c.rollback();throw e;} }
    }

    /** One row per selected meal, or one row for a non-meal request. */
    public List<Map<String,Object>> adminDonationRequests() throws Exception {
        return query("SELECT ROW_NUMBER() OVER (PARTITION BY r.request_id ORDER BY m.meal_id) request_row_index,UUID() receipt_token,r.request_id,r.request_code,r.donor_name,r.donor_phone,r.donor_email,r.request_type,r.requested_date,r.purpose,r.request_message,r.estimated_amount,r.request_status,r.created_at,m.meal_id,m.meal_date,m.meal_slot,m.meal_status FROM donation_requests r LEFT JOIN donation_request_meals m ON m.request_id=r.request_id ORDER BY CASE r.request_status WHEN 'NEW' THEN 0 WHEN 'CONTACTED' THEN 1 WHEN 'AGREED' THEN 2 WHEN 'PARTIALLY_RECEIVED' THEN 3 ELSE 4 END,r.created_at DESC,m.meal_date,m.meal_slot", "request_row_index","receipt_token","request_id","request_code","donor_name","donor_phone","donor_email","request_type","requested_date","purpose","request_message","estimated_amount","request_status","created_at","meal_id","meal_date","meal_slot","meal_status");
    }

    public List<Map<String,Object>> receivedDonationReceipts() throws Exception {
        return query("SELECT x.receipt_id,x.request_id,x.received_date,x.donation_kind,x.amount_received,x.item_description,x.public_name,x.show_public,x.created_at,r.request_code,r.donor_name,r.request_type,m.meal_slot,m.meal_date FROM donation_receipts x JOIN donation_requests r ON r.request_id=x.request_id LEFT JOIN donation_request_meals m ON m.meal_id=x.meal_id ORDER BY x.received_date DESC,x.created_at DESC", "receipt_id","request_id","received_date","donation_kind","amount_received","item_description","public_name","show_public","created_at","request_code","donor_name","request_type","meal_slot","meal_date");
    }

    public void updateDonationRequest(int adminId,int requestId,String status,String adminNote,String ip) throws Exception {
        if(!Set.of("CONTACTED","AGREED","CANCELLED").contains(status)) throw new IllegalArgumentException("Choose a valid request status.");
        if(adminNote!=null && adminNote.length()>1000) throw new IllegalArgumentException("Admin note is too long.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String old;
            try(PreparedStatement p=c.prepareStatement("SELECT request_status FROM donation_requests WHERE request_id=? FOR UPDATE")){p.setInt(1,requestId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Donation request not found.");old=r.getString(1);}}
            if(Set.of("RECEIVED","CANCELLED","PARTIALLY_RECEIVED").contains(old))throw new SQLException("This donation request is already completed, partially received or cancelled.");
            if("AGREED".equals(old) && "CONTACTED".equals(status))throw new SQLException("An agreed donation request cannot be moved backwards to CONTACTED.");
            if("AGREED".equals(old) && !Set.of("AGREED","CANCELLED").contains(status))throw new SQLException("Only cancellation is available after the donor has agreed.");
            try(PreparedStatement p=c.prepareStatement("UPDATE donation_requests SET request_status=?,admin_note=?,updated_at=NOW() WHERE request_id=?")){p.setString(1,status);p.setString(2,adminNote==null?null:adminNote.trim());p.setInt(3,requestId);p.executeUpdate();}
            if("AGREED".equals(status))try(PreparedStatement p=c.prepareStatement("UPDATE donation_request_meals SET meal_status='AGREED' WHERE request_id=? AND meal_status='REQUESTED'")){p.setInt(1,requestId);p.executeUpdate();}
            if("CANCELLED".equals(status))try(PreparedStatement p=c.prepareStatement("UPDATE donation_request_meals SET meal_status='CANCELLED' WHERE request_id=? AND meal_status IN ('REQUESTED','AGREED')")){p.setInt(1,requestId);p.executeUpdate();}
            audit(c,adminId,"DONATION_REQUEST_"+status,"DONATION_REQUEST",requestId,ip,"Donation request moved from "+old+" to "+status);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }

    public void recordRequestReceipt(int adminId,int requestId,Integer mealId,String donationKind,BigDecimal amount,
            String itemDescription,java.sql.Date receivedDate,String publicName,boolean showPublic,String receiptToken,String ip) throws Exception {
        if(!Set.of("MONEY","FOOD","MEDICINE","SUPPLIES","OTHER").contains(donationKind))throw new IllegalArgumentException("Choose a valid received donation type.");
        if(amount!=null && (amount.signum()<=0 || amount.precision()>12 || amount.scale()>2))throw new IllegalArgumentException("Enter a valid received amount.");
        if((itemDescription==null||itemDescription.isBlank()) && amount==null)throw new IllegalArgumentException("Enter an amount or describe the items received.");
        if(itemDescription!=null && itemDescription.length()>500)throw new IllegalArgumentException("Description is too long.");
        if(publicName!=null && publicName.length()>100)throw new IllegalArgumentException("Public name is too long.");
        if(receivedDate==null)throw new IllegalArgumentException("Select the date received.");
        if(receiptToken==null||!receiptToken.matches("[0-9a-fA-F-]{36}"))throw new IllegalArgumentException("Refresh the donation record form and try again.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            String type; String donor;
            try(PreparedStatement p=c.prepareStatement("SELECT request_type,donor_name,request_status FROM donation_requests WHERE request_id=? FOR UPDATE")){p.setInt(1,requestId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Donation request not found.");type=r.getString(1);donor=r.getString(2);String st=r.getString(3);
                // The request row lock serializes concurrent submissions; an existing token makes a retry safe.
                try(PreparedStatement existing=c.prepareStatement("SELECT receipt_id FROM donation_receipts WHERE receipt_token=?")){existing.setString(1,receiptToken);try(ResultSet found=existing.executeQuery()){if(found.next()){c.commit();return;}}}
                if(!Set.of("AGREED","PARTIALLY_RECEIVED").contains(st))throw new SQLException("Contact the donor and mark the request as AGREED before recording a receipt.");}}
            Integer validMealId=mealId;
            if("MEAL".equals(type)) {
                if(validMealId==null || validMealId<=0)throw new IllegalArgumentException("Select the meal that has actually been received.");
                try(PreparedStatement p=c.prepareStatement("SELECT meal_status FROM donation_request_meals WHERE meal_id=? AND request_id=? FOR UPDATE")){p.setInt(1,validMealId);p.setInt(2,requestId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("Selected meal is not part of this request.");if(Set.of("RECEIVED","CANCELLED").contains(r.getString(1)))throw new SQLException("This meal is already received or cancelled.");}}
            } else if(validMealId!=null) throw new IllegalArgumentException("Non-meal donations do not use meal slots.");
            int receiptId;
            try(PreparedStatement p=c.prepareStatement("INSERT INTO donation_receipts(request_id,meal_id,received_date,donation_kind,amount_received,item_description,public_name,show_public,verified_by_user_id,receipt_token) VALUES(?,?,?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){
                p.setInt(1,requestId);if(validMealId==null)p.setNull(2,Types.INTEGER);else p.setInt(2,validMealId);p.setDate(3,receivedDate);p.setString(4,donationKind);if(amount==null)p.setNull(5,Types.DECIMAL);else p.setBigDecimal(5,amount);p.setString(6,itemDescription==null?null:itemDescription.trim());p.setString(7,(publicName==null||publicName.isBlank())?donor:publicName.trim());p.setBoolean(8,showPublic);p.setInt(9,adminId);p.setString(10,receiptToken);
                try { p.executeUpdate(); } catch(SQLIntegrityConstraintViolationException duplicate) { try(PreparedStatement existing=c.prepareStatement("SELECT receipt_id FROM donation_receipts WHERE receipt_token=?")){existing.setString(1,receiptToken);try(ResultSet r=existing.executeQuery()){if(r.next()){c.commit();return;}else throw duplicate;}} }
                try(ResultSet k=p.getGeneratedKeys()){if(!k.next())throw new SQLException("Receipt was not created.");receiptId=k.getInt(1);}}
            if(validMealId!=null)try(PreparedStatement p=c.prepareStatement("UPDATE donation_request_meals SET meal_status='RECEIVED',received_at=NOW() WHERE meal_id=? AND request_id=?")){p.setInt(1,validMealId);p.setInt(2,requestId);p.executeUpdate();}
            String next="RECEIVED";
            if("MEAL".equals(type))try(PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM donation_request_meals WHERE request_id=? AND meal_status<>'RECEIVED' AND meal_status<>'CANCELLED'")){p.setInt(1,requestId);try(ResultSet r=p.executeQuery()){r.next();if(r.getInt(1)>0)next="PARTIALLY_RECEIVED";}}
            try(PreparedStatement p=c.prepareStatement("UPDATE donation_requests SET request_status=?,updated_at=NOW() WHERE request_id=?")){p.setString(1,next);p.setInt(2,requestId);p.executeUpdate();}
            audit(c,adminId,"DONATION_RECEIPT_RECORDED","DONATION_RECEIPT",receiptId,ip,"Received donation for request "+requestId);c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }

    public void addDonationStories(int adminId,int receiptId,java.sql.Date mealDate,String caption,List<String> imagePaths,boolean publish,String ip) throws Exception {
        if(imagePaths==null||imagePaths.isEmpty())throw new IllegalArgumentException("Choose at least one feeding photo.");
        if(caption!=null && caption.length()>500)throw new IllegalArgumentException("Caption is too long.");
        try(Connection c=DBConnection.getConnection()){c.setAutoCommit(false);try{
            if(mealDate==null) throw new IllegalArgumentException("Select the actual meal date.");
            int requestId; String slot; java.sql.Date confirmedMealDate;
            try(PreparedStatement p=c.prepareStatement("SELECT x.request_id,m.meal_slot,m.meal_date FROM donation_receipts x JOIN donation_requests r ON r.request_id=x.request_id JOIN donation_request_meals m ON m.meal_id=x.meal_id WHERE x.receipt_id=? AND r.request_type='MEAL' FOR UPDATE")){p.setInt(1,receiptId);try(ResultSet r=p.executeQuery()){if(!r.next())throw new SQLException("A confirmed meal receipt is required before adding a feeding story.");requestId=r.getInt(1);slot=r.getString(2);confirmedMealDate=r.getDate(3);}}
            if(!confirmedMealDate.equals(mealDate)) throw new IllegalArgumentException("The feeding story date must match the confirmed meal date.");
            String safeCaption=(caption==null||caption.isBlank())?"Thank you for helping provide this meal.":caption.trim();
            for(String path:imagePaths)try(PreparedStatement p=c.prepareStatement("INSERT INTO donation_meal_stories(receipt_id,request_id,meal_date,meal_slot,caption,photo_path,is_published,created_by_user_id) VALUES(?,?,?,?,?,?,?,?)")){p.setInt(1,receiptId);p.setInt(2,requestId);p.setDate(3,mealDate);p.setString(4,slot);p.setString(5,safeCaption);p.setString(6,path);p.setBoolean(7,publish);p.setInt(8,adminId);p.executeUpdate();}
            audit(c,adminId,"DONATION_MEAL_STORY_CREATED","DONATION_RECEIPT",receiptId,ip,"Uploaded "+imagePaths.size()+" meal photos");c.commit();
        }catch(Exception e){c.rollback();throw e;}}
    }

    public List<Map<String,Object>> donationTicker() throws Exception {
        return query("SELECT CASE WHEN x.show_public=1 THEN COALESCE(NULLIF(x.public_name,''),'A PawHome supporter') ELSE 'A kind supporter' END donor_name,CASE WHEN r.request_type='MEAL' THEN CONCAT('supported ',LOWER(m.meal_slot),' on ',DATE_FORMAT(m.meal_date,'%e %b')) WHEN r.request_type='MEDICAL_CARE' THEN 'supported animal medical care' WHEN r.request_type='SUPPLIES' THEN 'donated animal care supplies' ELSE 'supported PawHome animals' END ticker_text FROM donation_receipts x JOIN donation_requests r ON r.request_id=x.request_id LEFT JOIN donation_request_meals m ON m.meal_id=x.meal_id ORDER BY x.received_date DESC,x.created_at DESC LIMIT 12", "donor_name","ticker_text");
    }

    public List<Map<String,Object>> todayMealStories(java.sql.Date today) throws Exception {
        String sql = "SELECT s.story_id,s.meal_date,s.meal_slot,s.caption,s.photo_path,r.donor_name,CASE WHEN x.show_public=1 THEN COALESCE(NULLIF(x.public_name,''),'A PawHome supporter') ELSE 'A kind supporter' END public_name FROM donation_meal_stories s JOIN donation_receipts x ON x.receipt_id=s.receipt_id JOIN donation_requests r ON r.request_id=s.request_id WHERE s.is_published=1 AND s.meal_date=? ORDER BY s.created_at DESC";
        return query(sql, today, "story_id","meal_date","meal_slot","caption","photo_path","donor_name","public_name");
    }

    private static void require(String value,int max,String field){if(value==null||value.isBlank()||value.trim().length()>max)throw new IllegalArgumentException("Enter a valid "+field+" (maximum "+max+" characters).");}
    private void audit(Connection c,int userId,String action,String type,int id,String ip,String details)throws SQLException{
        try(PreparedStatement p=c.prepareStatement("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,ip_address,details) VALUES(?,?,?,?,?,?)")){p.setInt(1,userId);p.setString(2,action);p.setString(3,type);if(id<=0)p.setNull(4,Types.INTEGER);else p.setInt(4,id);p.setString(5,ip);p.setString(6,details);p.executeUpdate();}
    }
}
