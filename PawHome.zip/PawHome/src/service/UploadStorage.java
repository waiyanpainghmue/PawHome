package service;

import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Validates image bytes and stores uploads outside the deployed web application. */
public final class UploadStorage {
    private static final long MAX_IMAGE_BYTES = 5L * 1024 * 1024;
    private UploadStorage() { }

    public static Path root() {
        String configured = System.getProperty("pawhome.upload.dir");
        if (configured == null || configured.isBlank()) configured = System.getenv("PAWHOME_UPLOAD_DIR");
        if (configured == null || configured.isBlank()) configured = System.getProperty("catalina.base", ".") + "/pawhome-uploads";
        return Paths.get(configured).toAbsolutePath().normalize();
    }

    public static List<String> saveImages(Collection<Part> parts, String folder, int maxFiles) throws IOException {
        List<String> stored = new ArrayList<>();
        if (parts == null) return stored;
        try {
            for (Part part : parts) {
                String submitted = part.getSubmittedFileName();
                if (submitted == null || submitted.isBlank() || part.getSize() == 0) continue;
                if (stored.size() >= maxFiles) throw new IOException("You can upload at most " + maxFiles + " images.");
                if (part.getSize() > MAX_IMAGE_BYTES) throw new IOException("Each image must be 5 MB or smaller.");
                byte[] data;
                try (InputStream in = part.getInputStream()) { data = in.readNBytes((int) MAX_IMAGE_BYTES + 1); }
                if (data.length == 0 || data.length > MAX_IMAGE_BYTES) throw new IOException("Image exceeds the allowed file size.");
                String extension = detectImageExtension(data);
                if (extension == null) throw new IOException("Only valid JPG, PNG or WebP image files are accepted.");
                String fileName = UUID.randomUUID().toString() + extension;
                Path directory = root().resolve(folder).normalize();
                if (!directory.startsWith(root())) throw new IOException("Invalid upload destination.");
                Files.createDirectories(directory);
                Files.write(directory.resolve(fileName), data, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                stored.add("media/" + folder + "/" + fileName);
            }
            return stored;
        } catch (IOException | RuntimeException e) {
            deleteStored(stored);
            throw e;
        }
    }

    private static String detectImageExtension(byte[] b) {
        if (b.length >= 3 && (b[0] & 255) == 0xFF && (b[1] & 255) == 0xD8 && (b[2] & 255) == 0xFF) return ".jpg";
        if (b.length >= 8 && (b[0] & 255) == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47 && b[4] == 0x0D && b[5] == 0x0A && b[6] == 0x1A && b[7] == 0x0A) return ".png";
        if (b.length >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return ".webp";
        return null;
    }

    public static void deleteStored(List<String> paths) {
        if (paths == null) return;
        for (String value : paths) {
            if (value == null || !value.startsWith("media/")) continue;
            Path target = root().resolve(value.substring("media/".length())).normalize();
            if (target.startsWith(root())) try { Files.deleteIfExists(target); } catch (IOException ignored) { }
        }
    }
}
